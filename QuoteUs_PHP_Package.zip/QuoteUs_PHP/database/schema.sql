-- QuoteUs.ca MySQL Schema
-- MySQL 5.7+ Compatible

SET FOREIGN_KEY_CHECKS=0;

-- Drop tables in reverse order
DROP TABLE IF EXISTS partner_redirects;
DROP TABLE IF EXISTS broker_notes;
DROP TABLE IF EXISTS advertisements;
DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS activities;
DROP TABLE IF EXISTS quotes;
DROP TABLE IF EXISTS system_settings;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS=1;

-- ============================================================
-- 1. USERS
-- ============================================================
CREATE TABLE users (
  id CHAR(36) NOT NULL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  phone VARCHAR(50) DEFAULT NULL,
  password VARCHAR(255) DEFAULT NULL,
  role ENUM('admin','manager','broker','customer') NOT NULL DEFAULT 'customer',
  status ENUM('active','pending','paused','cancelled','denied') NOT NULL DEFAULT 'active',
  balance DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  lead_cost_override DECIMAL(10,2) DEFAULT NULL,
  stripe_customer_id VARCHAR(255) DEFAULT NULL,
  brokerage VARCHAR(255) DEFAULT NULL,
  years_of_service INT DEFAULT NULL,
  product_types JSON DEFAULT NULL,
  permissions JSON DEFAULT NULL,
  reset_token VARCHAR(255) DEFAULT NULL,
  reset_token_expiry DATETIME DEFAULT NULL,
  pause_start_date DATETIME DEFAULT NULL,
  pause_end_date DATETIME DEFAULT NULL,
  google_id VARCHAR(255) DEFAULT NULL,
  assigned_postal_codes JSON DEFAULT NULL,
  assigned_cities JSON DEFAULT NULL,
  broker_tier ENUM('bronze','silver','gold','platinum') DEFAULT NULL,
  preferred_insurance_types JSON DEFAULT NULL,
  preferred_demographics TEXT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 2. SYSTEM_SETTINGS
-- ============================================================
CREATE TABLE system_settings (
  id CHAR(36) NOT NULL PRIMARY KEY,
  `key` VARCHAR(255) NOT NULL UNIQUE,
  value TEXT NOT NULL,
  updated_by CHAR(36) DEFAULT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 3. QUOTES
-- ============================================================
CREATE TABLE quotes (
  id CHAR(36) NOT NULL PRIMARY KEY,
  quote_number VARCHAR(50) NOT NULL UNIQUE,
  type ENUM('Auto','Home','Tenant','Business','Life','Travel','Pet','Mortgage','General') NOT NULL,
  client_name VARCHAR(255) NOT NULL,
  email VARCHAR(255) DEFAULT NULL,
  phone VARCHAR(50) DEFAULT NULL,
  postal_code VARCHAR(20) DEFAULT NULL,
  status ENUM('New','Contacted','Quoted','Bound','Follow-Up','Closed','Lost','Win','Lose','Expired') NOT NULL DEFAULT 'New',
  priority ENUM('High','Medium','Low') NOT NULL DEFAULT 'Medium',
  source VARCHAR(100) NOT NULL DEFAULT 'Web Form',
  assigned_to CHAR(36) DEFAULT NULL,
  assigned_at DATETIME DEFAULT NULL,
  internal_notes TEXT DEFAULT NULL,
  details JSON NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_quotes_assigned_to (assigned_to)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 4. ACTIVITIES
-- ============================================================
CREATE TABLE activities (
  id CHAR(36) NOT NULL PRIMARY KEY,
  quote_id CHAR(36) NOT NULL,
  type ENUM('status_change','assignment','note','email_sent','system') NOT NULL,
  content TEXT NOT NULL,
  author VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_activities_quote_id (quote_id),
  FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 5. TRANSACTIONS
-- ============================================================
CREATE TABLE transactions (
  id CHAR(36) NOT NULL PRIMARY KEY,
  user_id CHAR(36) NOT NULL,
  type ENUM('credit_purchase','lead_deduction','manual_credit','adjustment','refund') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  balance_after DECIMAL(10,2) NOT NULL,
  description TEXT NOT NULL,
  reason TEXT DEFAULT NULL,
  quote_id CHAR(36) DEFAULT NULL,
  stripe_payment_id VARCHAR(255) DEFAULT NULL,
  actor_id CHAR(36) DEFAULT NULL,
  actor_name VARCHAR(255) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_transactions_user_id (user_id),
  KEY idx_transactions_quote_id (quote_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 6. ADVERTISEMENTS
-- ============================================================
CREATE TABLE advertisements (
  id CHAR(36) NOT NULL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  media_type ENUM('image','video') NOT NULL DEFAULT 'image',
  media_url TEXT NOT NULL,
  link_url TEXT DEFAULT NULL,
  open_in_popup TINYINT(1) NOT NULL DEFAULT 0,
  target_pages JSON NOT NULL,
  status ENUM('active','paused','scheduled','expired') NOT NULL DEFAULT 'active',
  start_date DATETIME DEFAULT NULL,
  end_date DATETIME DEFAULT NULL,
  priority INT NOT NULL DEFAULT 1,
  impressions INT NOT NULL DEFAULT 0,
  clicks INT NOT NULL DEFAULT 0,
  preview_token CHAR(36) DEFAULT NULL,
  approval_status VARCHAR(50) DEFAULT 'pending',
  ad_text TEXT DEFAULT NULL,
  text_color VARCHAR(20) DEFAULT '#ffffff',
  background_color VARCHAR(20) DEFAULT '#1e3a5f',
  text_position VARCHAR(20) DEFAULT 'bottom',
  top_text TEXT DEFAULT NULL,
  center_text TEXT DEFAULT NULL,
  bottom_text TEXT DEFAULT NULL,
  top_text_color VARCHAR(20) DEFAULT '#ffffff',
  center_text_color VARCHAR(20) DEFAULT '#ffffff',
  bottom_text_color VARCHAR(20) DEFAULT '#ffffff',
  top_bg_color VARCHAR(20) DEFAULT '#1e3a5f',
  center_bg_color VARCHAR(20) DEFAULT '#1e3a5f',
  bottom_bg_color VARCHAR(20) DEFAULT '#1e3a5f',
  created_by CHAR(36) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_advertisements_created_by (created_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 7. BROKER_NOTES
-- ============================================================
CREATE TABLE broker_notes (
  id CHAR(36) NOT NULL PRIMARY KEY,
  broker_id CHAR(36) NOT NULL,
  author_id CHAR(36) NOT NULL,
  author_name VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_broker_notes_broker_id (broker_id),
  FOREIGN KEY (broker_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 8. PARTNER_REDIRECTS
-- ============================================================
CREATE TABLE partner_redirects (
  id CHAR(36) NOT NULL PRIMARY KEY,
  quote_type ENUM('Auto','Home','Tenant','Business','Life','Travel','Pet','Mortgage','General') NOT NULL UNIQUE,
  redirect_url TEXT NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  description TEXT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
