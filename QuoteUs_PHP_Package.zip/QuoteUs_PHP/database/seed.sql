-- QuoteUs.ca Data Seed
-- Generated: 2026-02-22
-- Contains all current data from production database

SET FOREIGN_KEY_CHECKS=0;

-- Clear existing data
DELETE FROM broker_notes;
DELETE FROM partner_redirects;
DELETE FROM transactions;
DELETE FROM activities;
DELETE FROM advertisements;
DELETE FROM quotes;
DELETE FROM system_settings;
DELETE FROM users;

-- ============================================================
-- USERS (passwords are bcrypt hashed - default: password123)
-- ============================================================
INSERT INTO users (id, name, email, phone, password, role, status, balance, broker_tier, preferred_insurance_types, preferred_demographics, created_at) VALUES
('e965481e-b4a5-4708-82d1-76c73590354b', 'Account Manager', 'admin@quoteus.ca', '416-555-0100', '$2a$10$LhCVf.VKuvG4NSBA0o8hCuGe/kBxHLQY6RqWiSe4NSQJfYi0PIrWG', 'admin', 'active', 0.00, NULL, NULL, NULL, '2026-01-21 00:50:42'),
('1836d6cf-bea2-4119-b837-2ed14aa503e9', 'Sales Director', 'manager@quoteus.ca', '416-555-0101', '$2a$10$LhCVf.VKuvG4NSBA0o8hCuGe/kBxHLQY6RqWiSe4NSQJfYi0PIrWG', 'manager', 'active', 0.00, NULL, NULL, NULL, '2026-01-21 00:50:42'),
('193ab804-4c9d-4e20-9d12-697f86888a5a', 'John Broker', 'john@quoteus.ca', '416-555-0102', '$2a$10$LhCVf.VKuvG4NSBA0o8hCuGe/kBxHLQY6RqWiSe4NSQJfYi0PIrWG', 'broker', 'active', 74.00, 'gold', '["Tenant","Business","Life","Travel","Pet","Mortgage","Auto","Home"]', 'Looking for business outside of the GTA no L or M postal code', '2026-01-21 00:50:42'),
('753bd244-2a42-458a-8600-50d31bc11ba2', 'Sarah Agent', 'sarah@quoteus.ca', '416-555-0103', '$2a$10$LhCVf.VKuvG4NSBA0o8hCuGe/kBxHLQY6RqWiSe4NSQJfYi0PIrWG', 'broker', 'active', 100.00, NULL, NULL, NULL, '2026-01-21 00:50:42');

-- ============================================================
-- QUOTES
-- ============================================================
INSERT INTO quotes (id, quote_number, type, client_name, email, phone, postal_code, status, priority, source, assigned_to, details, created_at, updated_at) VALUES
('575b3235-55eb-48b0-aeae-c725ffab4944', 'Q-2026-4619', 'Business', 'Sam Woo', '13snid@gmai.co', '4168689989', 'M5A 1A1', 'Bound', 'Medium', 'Web Form', '193ab804-4c9d-4e20-9d12-697f86888a5a', '{"email": "13snid@gmai.co", "phone": "4168689989", "address": "124 Main Street, Toronto, ON", "revenue": "120000", "employees": "3", "postalCode": "M5A 1A1", "contactName": "Sam Woo", "businessName": "Amme a", "hasAttachment": false}', '2026-02-03 17:37:07', '2026-02-07 02:22:09'),
('8fe21706-b1fd-40e0-a7b5-ba88a89449da', 'Q-2026-3982', 'Travel', 'sam woo', 'ah@the.ca', '4162609220', 'm5n2h1', 'New', 'Medium', 'Web Form', '193ab804-4c9d-4e20-9d12-697f86888a5a', '{"email": "ah@the.ca", "phone": "4162609220", "address": "132 the", "lastName": "woo", "firstName": "sam", "postalCode": "m5n2h1", "returnDate": "2026-03-01", "travellers": "1", "destination": "caribbean", "departureDate": "2026-02-11", "primaryTravellerAge": "34", "preExistingCondition": "no"}', '2026-02-03 00:47:33', '2026-02-07 02:11:02'),
('df4243f2-7ef4-4bbc-84a7-556bd8c6ae04', 'Q-2026-8887', 'Travel', 'Don test', 'aha@the.aho', '4168689989', 'M5B2H1', 'Quoted', 'Medium', 'Web Form', '193ab804-4c9d-4e20-9d12-697f86888a5a', '{"email": "aha@the.aho", "phone": "4168689989", "address": "132 text street", "lastName": "test", "firstName": "Don", "postalCode": "M5B2H1", "returnDate": "2026-04-02", "travellers": "1", "destination": "caribbean", "departureDate": "2026-02-09", "primaryTravellerAge": "25", "preExistingCondition": "no"}', '2026-02-03 16:51:47', '2026-02-07 02:11:44'),
('af96fd4e-2b4a-451e-bc54-fe4b24f4d557', 'Q-2026-7370', 'Business', 'Sam Woo', '13snid@gmai.co', '4168689989', 'M5A 1A1', 'Bound', 'Medium', 'Web Form', '753bd244-2a42-458a-8600-50d31bc11ba2', '{"email": "13snid@gmai.co", "phone": "4168689989", "address": "124 Main Street, Toronto, ON", "revenue": "120000", "employees": "3", "postalCode": "M5A 1A1", "contactName": "Sam Woo", "businessName": "Amme a", "hasAttachment": false}', '2026-02-03 17:36:57', '2026-02-07 02:11:48');

-- ============================================================
-- ACTIVITIES
-- ============================================================
INSERT INTO activities (id, quote_id, type, content, author, created_at) VALUES
('561ebb94-68a1-428a-9d42-c0f7fc07fe43', '8fe21706-b1fd-40e0-a7b5-ba88a89449da', 'system', 'Lead created via Web Form', 'System', '2026-02-03 00:47:33'),
('6bc53db4-ad4c-4619-963d-9667815fd9e8', 'df4243f2-7ef4-4bbc-84a7-556bd8c6ae04', 'system', 'Lead created via Web Form', 'System', '2026-02-03 16:51:47'),
('d8aef698-7740-472e-a494-e0b8f74d3789', 'af96fd4e-2b4a-451e-bc54-fe4b24f4d557', 'system', 'Lead created via Web Form', 'System', '2026-02-03 17:36:57'),
('ba6a95d8-b388-41ce-bd8b-6b4b74e17591', '575b3235-55eb-48b0-aeae-c725ffab4944', 'system', 'Lead created via Web Form', 'System', '2026-02-03 17:37:07'),
('e65209a0-d292-47fd-9250-02090f584d32', '575b3235-55eb-48b0-aeae-c725ffab4944', 'assignment', 'Lead assigned to John Broker ($20 deducted)', 'Sales Director', '2026-02-07 02:10:41'),
('70e57968-6a2c-4901-9a97-52f00efca353', 'af96fd4e-2b4a-451e-bc54-fe4b24f4d557', 'assignment', 'Lead assigned to Sarah Agent ($20 deducted)', 'Sales Director', '2026-02-07 02:10:54'),
('7dd77fb0-a176-4b54-a2e0-5890ef5e5115', 'df4243f2-7ef4-4bbc-84a7-556bd8c6ae04', 'assignment', 'Lead assigned to John Broker ($3 deducted)', 'Sales Director', '2026-02-07 02:10:58'),
('e3cf6cbb-1d04-45e6-ad14-2e35626ebc45', '8fe21706-b1fd-40e0-a7b5-ba88a89449da', 'assignment', 'Lead assigned to John Broker ($3 deducted)', 'Sales Director', '2026-02-07 02:11:02'),
('fab0b1bd-f82c-49e8-a5b8-d475a27bd5fc', '575b3235-55eb-48b0-aeae-c725ffab4944', 'status_change', 'Status changed from New to Contacted', 'Sales Director', '2026-02-07 02:11:41'),
('2b48fb1b-ba9a-4aa7-aa4a-362ccff91ae2', 'df4243f2-7ef4-4bbc-84a7-556bd8c6ae04', 'status_change', 'Status changed from New to Quoted', 'Sales Director', '2026-02-07 02:11:44'),
('3fa9d9c5-a738-4f21-8e1c-8b97037da147', 'af96fd4e-2b4a-451e-bc54-fe4b24f4d557', 'status_change', 'Status changed from New to Bound', 'Sales Director', '2026-02-07 02:11:48'),
('2863d0f5-9ea9-455f-b726-c0548d2495a3', '575b3235-55eb-48b0-aeae-c725ffab4944', 'status_change', 'Status changed from Contacted to Quoted', 'Sales Director', '2026-02-07 02:20:09'),
('7f56e8fa-fea5-4704-9dc7-1f9e6c1040d6', '575b3235-55eb-48b0-aeae-c725ffab4944', 'status_change', 'Status changed from Quoted to Contacted', 'Sales Director', '2026-02-07 02:20:15'),
('b13b5de2-6ccd-4bbc-bff3-cd013ac5f259', '575b3235-55eb-48b0-aeae-c725ffab4944', 'status_change', 'Status changed from Contacted to New', 'Sales Director', '2026-02-07 02:20:17'),
('3a8fe4a7-ec5f-4deb-8c54-851ce8c909bf', '575b3235-55eb-48b0-aeae-c725ffab4944', 'status_change', 'Status changed from New to Contacted', 'Sales Director', '2026-02-07 02:20:27'),
('4babb73b-4d29-4590-8d1d-310a99d4c977', '575b3235-55eb-48b0-aeae-c725ffab4944', 'status_change', 'Status changed from Contacted to New', 'Sales Director', '2026-02-07 02:20:52'),
('ded98cdc-658a-4163-b2da-27351d183d39', '575b3235-55eb-48b0-aeae-c725ffab4944', 'status_change', 'Status changed from New to Contacted', 'Sales Director', '2026-02-07 02:22:05'),
('14edef83-361a-4d16-a926-5fd82fd50d0e', '575b3235-55eb-48b0-aeae-c725ffab4944', 'status_change', 'Status changed from Contacted to Quoted', 'Sales Director', '2026-02-07 02:22:07'),
('4abb6a3c-a659-4a31-948b-f7d9242beeca', '575b3235-55eb-48b0-aeae-c725ffab4944', 'status_change', 'Status changed from Quoted to Bound', 'Sales Director', '2026-02-07 02:22:09');

-- ============================================================
-- TRANSACTIONS
-- ============================================================
INSERT INTO transactions (id, user_id, type, amount, balance_after, description, reason, quote_id, actor_id, actor_name, created_at) VALUES
('0900de59-cc5f-4fd5-b533-6dd490e890d9', '193ab804-4c9d-4e20-9d12-697f86888a5a', 'manual_credit', 100.00, 100.00, 'Manual credit: start up', 'start up', NULL, 'e965481e-b4a5-4708-82d1-76c73590354b', 'Account Manager', '2026-02-07 02:00:34'),
('caa3cc50-035a-4240-b119-a83f0ee95810', '753bd244-2a42-458a-8600-50d31bc11ba2', 'manual_credit', 120.00, 120.00, 'Manual credit: paid', 'paid', NULL, 'e965481e-b4a5-4708-82d1-76c73590354b', 'Account Manager', '2026-02-07 02:01:44'),
('042c0a35-59fe-4f09-a1df-6312d00427f4', '193ab804-4c9d-4e20-9d12-697f86888a5a', 'lead_deduction', -20.00, 80.00, 'Lead assigned: Business - Sam Woo (Q-2026-4619)', NULL, '575b3235-55eb-48b0-aeae-c725ffab4944', '1836d6cf-bea2-4119-b837-2ed14aa503e9', 'Sales Director', '2026-02-07 02:10:41'),
('a3b44419-209e-48e6-8911-8bb4f07844e6', '753bd244-2a42-458a-8600-50d31bc11ba2', 'lead_deduction', -20.00, 100.00, 'Lead assigned: Business - Sam Woo (Q-2026-7370)', NULL, 'af96fd4e-2b4a-451e-bc54-fe4b24f4d557', '1836d6cf-bea2-4119-b837-2ed14aa503e9', 'Sales Director', '2026-02-07 02:10:54'),
('187b1515-3406-45d1-9b6b-b2cc654b5377', '193ab804-4c9d-4e20-9d12-697f86888a5a', 'lead_deduction', -3.00, 77.00, 'Lead assigned: Travel - Don test (Q-2026-8887)', NULL, 'df4243f2-7ef4-4bbc-84a7-556bd8c6ae04', '1836d6cf-bea2-4119-b837-2ed14aa503e9', 'Sales Director', '2026-02-07 02:10:58'),
('ae8037e4-ec71-47ec-b9fb-970c36839505', '193ab804-4c9d-4e20-9d12-697f86888a5a', 'lead_deduction', -3.00, 74.00, 'Lead assigned: Travel - sam woo (Q-2026-3982)', NULL, '8fe21706-b1fd-40e0-a7b5-ba88a89449da', '1836d6cf-bea2-4119-b837-2ed14aa503e9', 'Sales Director', '2026-02-07 02:11:02');

-- ============================================================
-- ADVERTISEMENTS
-- ============================================================
INSERT INTO advertisements (id, name, media_type, media_url, link_url, open_in_popup, target_pages, status, start_date, end_date, priority, impressions, clicks, preview_token, approval_status, text_color, background_color, text_position, bottom_text, top_text_color, center_text_color, bottom_text_color, top_bg_color, center_bg_color, bottom_bg_color, created_at) VALUES
('a1503462-0463-456a-ac04-facb370135c8', 'Multi Services', 'image', '/uploads/ad-1770487717984-93739826.png', NULL, 1, '["Auto","Pet","Tenant","Business","Travel"]', 'active', '2026-02-02 00:00:00', '2026-02-28 00:00:00', 1, 6, 0, 'e03cf4d7-e9b7-46c0-8e3a-ddcf262221d4', 'pending', '#ffffff', '#1e3a5f', 'bottom', NULL, '#ffffff', '#ffffff', '#ffffff', '#1e3a5f', '#1e3a5f', '#1e3a5f', '2026-02-07 18:08:45'),
('d6ddb105-3bb7-4b29-8f41-d5a00031dfa4', 'Maxwell Auto Repairs', 'image', '/uploads/ad-1770077913220-996385568.jpg', 'https://maxwellautomotive.com/', 1, '["all"]', 'active', '2026-02-02 00:00:00', '2026-02-28 00:00:00', 5, 22, 1, '870d7c22-c667-4368-87ff-5d795d7b2506', 'approved', '#ffffff', '#1e3a5f', 'bottom', 'Call now', '#ffffff', '#ffffff', '#ffffff', '#1e3a5f', '#1e3a5f', '#1e3a5f', '2026-02-02 17:26:56');

-- ============================================================
-- PARTNER_REDIRECTS
-- ============================================================
INSERT INTO partner_redirects (id, quote_type, redirect_url, is_active, description, created_at) VALUES
('3955eed9-51b4-460b-9df6-8e655941a913', 'Business', 'https://onekonnex.com/', 1, 'business OneKonnex', '2026-02-03 17:35:41');

SET FOREIGN_KEY_CHECKS=1;

-- Seed complete. Default login: admin@quoteus.ca / password123
