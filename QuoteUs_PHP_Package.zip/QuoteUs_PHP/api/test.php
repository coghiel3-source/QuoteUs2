<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';

$results = [
    'php_version' => phpversion(),
    'pdo_mysql' => extension_loaded('pdo_mysql') ? 'OK' : 'MISSING - install php-pdo-mysql',
    'mod_rewrite' => in_array('mod_rewrite', apache_get_modules() ?? []) ? 'OK' : 'Cannot detect (may still work)',
    'db_host' => DB_HOST,
    'db_name' => DB_NAME,
    'db_user' => DB_USER,
    'db_connection' => 'Testing...',
    'uploads_writable' => is_writable(__DIR__ . '/../uploads/') ? 'OK' : 'NOT WRITABLE - set permissions to 755',
];

try {
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $results['db_connection'] = 'OK - Connected successfully';

    $stmt = $pdo->query("SELECT COUNT(*) as cnt FROM users");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $results['users_count'] = $row['cnt'];

    $stmt = $pdo->query("SELECT COUNT(*) as cnt FROM quotes");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $results['quotes_count'] = $row['cnt'];

    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $results['tables'] = $tables;

} catch (\PDOException $e) {
    $results['db_connection'] = 'FAILED: ' . $e->getMessage();
}

echo json_encode($results, JSON_PRETTY_PRINT);
