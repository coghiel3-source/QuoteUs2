<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/email.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$DEFAULT_LEAD_COSTS = [
    'Auto'     => 10,
    'Home'     => 15,
    'Tenant'   => 5,
    'Business' => 20,
    'Life'     => 12,
    'Travel'   => 3,
    'Pet'      => 5,
    'General'  => 8,
];

$CREDIT_PACKAGES = [
    ['amount' => 25,  'label' => '$25'],
    ['amount' => 50,  'label' => '$50'],
    ['amount' => 100, 'label' => '$100'],
    ['amount' => 150, 'label' => '$150'],
    ['amount' => 200, 'label' => '$200'],
    ['amount' => 250, 'label' => '$250'],
];

function safeUser(?array $user): ?array {
    if ($user === null) return null;
    unset($user['password']);
    unset($user['resetToken']);
    unset($user['resetTokenExpiry']);
    return $user;
}

function safeUsers(array $users): array {
    return array_map('safeUser', $users);
}

function checkPermission(string $actorId, string $permission): bool {
    $db = getDB();
    $stmt = $db->prepare("SELECT value FROM system_settings WHERE `key` = 'manager_permissions'");
    $stmt->execute();
    $row = $stmt->fetch();
    if (!$row) return false;
    $perms = json_decode($row['value'], true);
    return isset($perms[$permission]) && $perms[$permission] === true;
}

function getLeadCosts(): array {
    global $DEFAULT_LEAD_COSTS;
    $db = getDB();
    $stmt = $db->prepare("SELECT value FROM system_settings WHERE `key` = 'lead_costs'");
    $stmt->execute();
    $row = $stmt->fetch();
    if ($row) {
        $parsed = json_decode($row['value'], true);
        if (is_array($parsed)) return $parsed;
    }
    return $DEFAULT_LEAD_COSTS;
}

function requireAdminOrManager(string $actorId): array {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$actorId]);
    $actor = $stmt->fetch();
    if (!$actor || ($actor['role'] !== 'admin' && $actor['role'] !== 'manager')) {
        jsonError('Only admin/manager can perform this action', 403);
    }
    return $actor;
}

function getSetting(string $key): ?string {
    $db = getDB();
    $stmt = $db->prepare("SELECT value FROM system_settings WHERE `key` = ?");
    $stmt->execute([$key]);
    $row = $stmt->fetch();
    return $row ? $row['value'] : null;
}

function setSetting(string $key, string $value, ?string $updatedBy = null): void {
    $db = getDB();
    $stmt = $db->prepare("SELECT id FROM system_settings WHERE `key` = ?");
    $stmt->execute([$key]);
    $exists = $stmt->fetch();
    if ($exists) {
        $stmt = $db->prepare("UPDATE system_settings SET value = ?, updated_by = ?, updated_at = NOW() WHERE `key` = ?");
        $stmt->execute([$value, $updatedBy, $key]);
    } else {
        $stmt = $db->prepare("INSERT INTO system_settings (id, `key`, value, updated_by) VALUES (?, ?, ?, ?)");
        $stmt->execute([uuid(), $key, $value, $updatedBy]);
    }
}

$method = $_SERVER['REQUEST_METHOD'];
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

$uri = preg_replace('#/api/index\.php/?#', '/', $uri);
$uri = preg_replace('#/api/#', '/', $uri);
$uri = preg_replace('#^/index\.php/?#', '/', $uri);

$parts = array_values(array_filter(explode('/', trim($uri, '/')), function($p) { return $p !== ''; }));
if (empty($parts)) {
    jsonResponse(['status' => 'ok', 'message' => 'QuoteUs.ca API']);
}

try {
    $db = getDB();
} catch (\Exception $e) {
    error_log("QuoteUs DB Connection Error: " . $e->getMessage());
    jsonError('Database connection failed. Check includes/config.php settings. Error: ' . $e->getMessage(), 500);
}

if ($parts[0] === 'auth' && ($parts[1] ?? '') === 'login' && $method === 'POST') {
    $input = jsonInput();
    $email = $input['email'] ?? null;
    $role  = $input['role'] ?? null;
    $password = $input['password'] ?? null;
    if (!$email) jsonError('Email is required', 400);
    if (!$password) jsonError('Password is required', 400);

    $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if (!$user) jsonError('User not found', 404);
    if ($role && $user['role'] !== $role) jsonError('Invalid role', 403);
    if (!verifyPassword($password, $user['password'] ?? '')) {
        jsonError('Invalid password', 401);
    }
    jsonResponse(safeUser(camelRow($user)));

} elseif ($parts[0] === 'auth' && ($parts[1] ?? '') === 'forgot-password' && $method === 'POST') {
    $input = jsonInput();
    $email = $input['email'] ?? null;
    if (!$email) jsonError('Email is required', 400);

    $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        $stmt = $db->prepare("UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE id = ?");
        $stmt->execute([$token, $expiry, $user['id']]);

        $baseUrl = $_SERVER['HTTP_HOST'] ?? 'quoteus.ca';
        $resetLink = "https://{$baseUrl}/reset-password?token={$token}";
        $emailContent = generatePasswordResetEmail($user['name'], $resetLink);
        sendEmail($user['email'], $emailContent['subject'], $emailContent['html']);
    }
    jsonResponse(['message' => 'If an account exists with that email, a reset link will be sent.']);

} elseif ($parts[0] === 'auth' && ($parts[1] ?? '') === 'verify-reset-token' && $method === 'GET') {
    $token = $_GET['token'] ?? null;
    if (!$token) jsonResponse(['valid' => false, 'error' => 'Token is required'], 400);

    $stmt = $db->prepare("SELECT * FROM users WHERE reset_token = ?");
    $stmt->execute([$token]);
    $user = $stmt->fetch();

    if (!$user || !$user['reset_token_expiry']) {
        jsonResponse(['valid' => false, 'error' => 'Invalid or expired token']);
    }
    if (strtotime($user['reset_token_expiry']) < time()) {
        $stmt = $db->prepare("UPDATE users SET reset_token = NULL, reset_token_expiry = NULL WHERE id = ?");
        $stmt->execute([$user['id']]);
        jsonResponse(['valid' => false, 'error' => 'Token has expired']);
    }
    jsonResponse(['valid' => true, 'email' => $user['email']]);

} elseif ($parts[0] === 'auth' && ($parts[1] ?? '') === 'reset-password' && $method === 'POST') {
    $input = jsonInput();
    $token    = $input['token'] ?? null;
    $password = $input['password'] ?? null;
    if (!$token || !$password) jsonError('Token and password are required', 400);

    $stmt = $db->prepare("SELECT * FROM users WHERE reset_token = ?");
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    if (!$user || !$user['reset_token_expiry']) jsonError('Invalid or expired token', 400);
    if (strtotime($user['reset_token_expiry']) < time()) {
        $stmt = $db->prepare("UPDATE users SET reset_token = NULL, reset_token_expiry = NULL WHERE id = ?");
        $stmt->execute([$user['id']]);
        jsonError('Token has expired', 400);
    }

    $stmt = $db->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE id = ?");
    $stmt->execute([hashPassword($password), $user['id']]);
    jsonResponse(['message' => 'Password has been reset successfully']);

} elseif ($parts[0] === 'users' && !isset($parts[1]) && $method === 'POST') {
    $input = jsonInput();
    $id = uuid();
    $stmt = $db->prepare("INSERT INTO users (id, name, email, password, role, phone, brokerage, years_of_service, status, balance) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    try {
        $stmt->execute([
            $id,
            $input['name'] ?? '',
            $input['email'] ?? '',
            hashPassword($input['password'] ?? 'changeme'),
            $input['role'] ?? 'broker',
            $input['phone'] ?? null,
            $input['brokerage'] ?? null,
            $input['yearsOfService'] ?? null,
            $input['status'] ?? 'active',
            $input['balance'] ?? '0.00',
        ]);
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        jsonResponse(safeUser(camelRow($stmt->fetch())), 201);
    } catch (\PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate') !== false || strpos($e->getMessage(), 'unique') !== false) {
            $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$input['email'] ?? '']);
            $existing = $stmt->fetch();
            if ($existing) {
                jsonResponse(safeUser(camelRow($existing)));
            }
        }
        throw $e;
    }

} elseif ($parts[0] === 'users' && !isset($parts[1]) && $method === 'GET') {
    $stmt = $db->query("SELECT * FROM users");
    jsonResponse(safeUsers(camelRows($stmt->fetchAll())));

} elseif ($parts[0] === 'users' && isset($parts[1]) && !isset($parts[2]) && $method === 'GET') {
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$parts[1]]);
    $user = $stmt->fetch();
    if (!$user) jsonError('User not found', 404);
    jsonResponse(safeUser(camelRow($user)));

} elseif ($parts[0] === 'users' && isset($parts[1]) && !isset($parts[2]) && $method === 'PATCH') {
    $input = jsonInput();
    $actorId = $input['actorId'] ?? null;
    if (!$actorId) jsonError('Actor ID is required for authentication', 401);

    $actor = requireAdminOrManager($actorId);
    if ($actor['role'] === 'manager') {
        if (!checkPermission($actorId, 'manageBrokers')) {
            jsonError("You don't have permission to manage brokers", 403);
        }
    }

    unset($input['actorId']);
    if (isset($input['password']) && $input['password'] !== '') {
        $input['password'] = hashPassword($input['password']);
    }
    $sets = [];
    $vals = [];
    foreach ($input as $col => $val) {
        $snake = strtolower(preg_replace('/[A-Z]/', '_$0', $col));
        $sets[] = "`{$snake}` = ?";
        $vals[] = is_array($val) ? json_encode($val) : $val;
    }
    if (empty($sets)) jsonError('No fields to update', 400);
    $vals[] = $parts[1];
    $stmt = $db->prepare("UPDATE users SET " . implode(', ', $sets) . " WHERE id = ?");
    $stmt->execute($vals);

    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$parts[1]]);
    $user = $stmt->fetch();
    if (!$user) jsonError('User not found', 404);
    jsonResponse(safeUser(camelRow($user)));

} elseif ($parts[0] === 'quotes' && !isset($parts[1]) && $method === 'POST') {
    $input = jsonInput();
    $id = uuid();
    $year = date('Y');
    $rand = str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT);
    $quoteNumber = "Q-{$year}-{$rand}";

    $stmt = $db->prepare("INSERT INTO quotes (id, quote_number, client_name, email, phone, postal_code, type, source, status, priority, details) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $id,
        $quoteNumber,
        $input['clientName'] ?? '',
        $input['email'] ?? null,
        $input['phone'] ?? null,
        $input['postalCode'] ?? null,
        $input['type'] ?? 'General',
        $input['source'] ?? 'Website',
        $input['status'] ?? 'New',
        $input['priority'] ?? 'Medium',
        isset($input['details']) ? json_encode($input['details']) : null,
    ]);

    $stmt = $db->prepare("SELECT * FROM quotes WHERE id = ?");
    $stmt->execute([$id]);
    $quote = $stmt->fetch();

    $actId = uuid();
    $stmt = $db->prepare("INSERT INTO activities (id, quote_id, type, content, author) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$actId, $id, 'system', "Lead created via " . ($input['source'] ?? 'Website'), 'System']);

    $notificationEmail = getSetting('notification_email') ?? 'info@quoteus.ca';
    $leadEmail = generateNewLeadEmail(
        $input['clientName'] ?? '',
        $input['type'] ?? 'General',
        $input['email'] ?? '',
        $input['phone'] ?? null,
        $input['source'] ?? 'Website'
    );
    sendEmail($notificationEmail, $leadEmail['subject'], $leadEmail['html']);

    if (!empty($input['email'])) {
        $thankYou = generateThankYouEmail($input['clientName'] ?? '', $input['type'] ?? 'General');
        sendEmail($input['email'], $thankYou['subject'], $thankYou['html']);
    }

    jsonResponse(camelRow($quote), 201);

} elseif ($parts[0] === 'quotes' && !isset($parts[1]) && $method === 'GET') {
    $stmt = $db->query("SELECT * FROM quotes ORDER BY created_at DESC");
    jsonResponse(camelRows($stmt->fetchAll()));

} elseif ($parts[0] === 'quotes' && isset($parts[1]) && ($parts[2] ?? '') === 'activities' && $method === 'GET') {
    $stmt = $db->prepare("SELECT * FROM activities WHERE quote_id = ? ORDER BY created_at DESC");
    $stmt->execute([$parts[1]]);
    jsonResponse(camelRows($stmt->fetchAll()));

} elseif ($parts[0] === 'quotes' && isset($parts[1]) && !isset($parts[2]) && $method === 'GET') {
    $stmt = $db->prepare("SELECT * FROM quotes WHERE id = ?");
    $stmt->execute([$parts[1]]);
    $quote = $stmt->fetch();
    if (!$quote) jsonError('Quote not found', 404);
    jsonResponse(camelRow($quote));

} elseif ($parts[0] === 'quotes' && isset($parts[1]) && !isset($parts[2]) && $method === 'PATCH') {
    $input = jsonInput();
    $stmt = $db->prepare("SELECT * FROM quotes WHERE id = ?");
    $stmt->execute([$parts[1]]);
    $existingQuote = $stmt->fetch();
    if (!$existingQuote) jsonError('Quote not found', 404);

    $sets = [];
    $vals = [];
    foreach ($input as $col => $val) {
        $snake = strtolower(preg_replace('/[A-Z]/', '_$0', $col));
        $sets[] = "`{$snake}` = ?";
        $vals[] = is_array($val) ? json_encode($val) : $val;
    }
    $sets[] = "updated_at = NOW()";
    $vals[] = $parts[1];
    $stmt = $db->prepare("UPDATE quotes SET " . implode(', ', $sets) . " WHERE id = ?");
    $stmt->execute($vals);

    $stmt = $db->prepare("SELECT * FROM quotes WHERE id = ?");
    $stmt->execute([$parts[1]]);
    $quote = $stmt->fetch();

    if (!empty($input['assignedTo']) && $input['assignedTo'] !== $existingQuote['assigned_to']) {
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$input['assignedTo']]);
        $broker = $stmt->fetch();
        if ($broker && $broker['email']) {
            $assignEmail = generateAssignmentEmail(
                $broker['name'],
                $quote['client_name'],
                $quote['type'],
                $quote['email'] ?? '',
                $quote['phone'] ?? null,
                $input['assignedBy'] ?? 'Admin'
            );
            sendEmail($broker['email'], $assignEmail['subject'], $assignEmail['html']);
        }
    }

    if (!empty($input['status']) && $input['status'] !== $existingQuote['status']) {
        if ($quote['assigned_to']) {
            $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$quote['assigned_to']]);
            $broker = $stmt->fetch();
            if ($broker && $broker['email']) {
                $statusHtml = "<div style='font-family:Arial,sans-serif;max-width:600px;margin:0 auto;'>
                    <div style='background-color:#16a34a;color:white;padding:20px;text-align:center;'><h1 style='margin:0;'>QuoteUs.ca</h1></div>
                    <div style='padding:30px;background-color:#f9fafb;'>
                        <h2 style='color:#1f2937;margin-top:0;'>Lead Status Updated</h2>
                        <p>The status for <strong>{$quote['client_name']}</strong> ({$quote['type']}) has been changed from <strong>{$existingQuote['status']}</strong> to <strong>{$input['status']}</strong>.</p>
                        <p>Changed by: " . ($input['changedBy'] ?? 'Admin') . "</p>
                    </div>
                </div>";
                sendEmail($broker['email'], "Status Update: {$quote['client_name']} - {$quote['type']}", $statusHtml);
            }
        }
    }

    jsonResponse(camelRow($quote));

} elseif ($parts[0] === 'quotes' && isset($parts[1]) && !isset($parts[2]) && $method === 'DELETE') {
    $stmt = $db->prepare("DELETE FROM quotes WHERE id = ?");
    $stmt->execute([$parts[1]]);
    if ($stmt->rowCount() === 0) jsonError('Quote not found', 404);
    http_response_code(204);
    exit;

} elseif ($parts[0] === 'leads' && isset($parts[1]) && ($parts[2] ?? '') === 'send-to-broker' && $method === 'POST') {
    $stmt = $db->prepare("SELECT * FROM quotes WHERE id = ?");
    $stmt->execute([$parts[1]]);
    $quote = $stmt->fetch();
    if (!$quote) jsonError('Lead not found', 404);
    if (!$quote['assigned_to']) jsonError('Lead is not assigned to a broker', 400);

    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$quote['assigned_to']]);
    $broker = $stmt->fetch();
    if (!$broker) jsonError('Assigned broker not found', 404);
    if (!$broker['email']) jsonError('Broker does not have an email address', 400);

    $details = $quote['details'] ? json_decode($quote['details'], true) : [];
    $detailsBlock = '';
    if (!empty($details)) {
        $detailsBlock = "<h3 style='color:#1f2937;margin-top:30px;'>Additional Details</h3>
            <div style='background:white;border-radius:8px;padding:20px;margin:20px 0;'>
                <pre style='white-space:pre-wrap;word-wrap:break-word;font-family:monospace;font-size:12px;color:#4b5563;margin:0;'>" . htmlspecialchars(json_encode($details, JSON_PRETTY_PRINT)) . "</pre>
            </div>";
    }

    $emailHtml = "<div style='font-family:Arial,sans-serif;max-width:600px;margin:0 auto;'>
        <div style='background-color:#16a34a;color:white;padding:20px;text-align:center;'><h1 style='margin:0;'>QuoteUs.ca</h1></div>
        <div style='padding:30px;background-color:#f9fafb;'>
            <h2 style='color:#1f2937;margin-top:0;'>Lead Details - {$quote['type']} Insurance</h2>
            <p style='color:#4b5563;'>You have been assigned a new lead. Here are the complete details:</p>
            <div style='background:white;border-radius:8px;padding:20px;margin:20px 0;'>
                <table style='width:100%;border-collapse:collapse;'>
                    <tr><td style='padding:10px 0;color:#6b7280;border-bottom:1px solid #e5e7eb;width:140px;'><strong>Client Name:</strong></td><td style='padding:10px 0;color:#1f2937;border-bottom:1px solid #e5e7eb;'>{$quote['client_name']}</td></tr>
                    <tr><td style='padding:10px 0;color:#6b7280;border-bottom:1px solid #e5e7eb;'><strong>Insurance Type:</strong></td><td style='padding:10px 0;color:#1f2937;border-bottom:1px solid #e5e7eb;'>{$quote['type']}</td></tr>
                    <tr><td style='padding:10px 0;color:#6b7280;border-bottom:1px solid #e5e7eb;'><strong>Email:</strong></td><td style='padding:10px 0;color:#1f2937;border-bottom:1px solid #e5e7eb;'>" . ($quote['email'] ?: 'Not provided') . "</td></tr>
                    <tr><td style='padding:10px 0;color:#6b7280;border-bottom:1px solid #e5e7eb;'><strong>Phone:</strong></td><td style='padding:10px 0;color:#1f2937;border-bottom:1px solid #e5e7eb;'>" . ($quote['phone'] ?: 'Not provided') . "</td></tr>
                    <tr><td style='padding:10px 0;color:#6b7280;border-bottom:1px solid #e5e7eb;'><strong>Postal Code:</strong></td><td style='padding:10px 0;color:#1f2937;border-bottom:1px solid #e5e7eb;'>" . ($quote['postal_code'] ?: 'Not provided') . "</td></tr>
                    <tr><td style='padding:10px 0;color:#6b7280;border-bottom:1px solid #e5e7eb;'><strong>Status:</strong></td><td style='padding:10px 0;color:#1f2937;border-bottom:1px solid #e5e7eb;'>{$quote['status']}</td></tr>
                    <tr><td style='padding:10px 0;color:#6b7280;border-bottom:1px solid #e5e7eb;'><strong>Priority:</strong></td><td style='padding:10px 0;color:#1f2937;border-bottom:1px solid #e5e7eb;'>" . ($quote['priority'] ?: 'Medium') . "</td></tr>
                    <tr><td style='padding:10px 0;color:#6b7280;'><strong>Source:</strong></td><td style='padding:10px 0;color:#1f2937;'>" . ($quote['source'] ?: 'Website') . "</td></tr>
                </table>
            </div>
            {$detailsBlock}
            <p style='color:#4b5563;font-size:14px;margin-top:20px;'>Please contact the client at your earliest convenience.</p>
            <p style='color:#4b5563;font-size:14px;margin-top:20px;'>Best regards,<br><strong>QuoteUs.ca Management</strong></p>
        </div>
        <div style='padding:20px;text-align:center;color:#9ca3af;font-size:12px;'><p>QuoteUs.ca - Your Trusted Ontario Insurance Partner</p></div>
    </div>";

    sendEmail($broker['email'], "Lead Assignment: {$quote['client_name']} - {$quote['type']} Insurance", $emailHtml);

    $actId = uuid();
    $stmt = $db->prepare("INSERT INTO activities (id, quote_id, type, content, author) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$actId, $quote['id'], 'email_sent', "Lead details emailed to broker {$broker['name']}", 'System']);

    jsonResponse(['success' => true, 'message' => 'Email sent to broker']);

} elseif ($parts[0] === 'leads' && ($parts[1] ?? '') === 'assign' && $method === 'POST') {
    $input = jsonInput();
    $quoteId  = $input['quoteId'] ?? null;
    $brokerId = $input['brokerId'] ?? null;
    $actorId  = $input['actorId'] ?? null;
    $actorName = $input['actorName'] ?? 'Admin';

    if (!$quoteId || !$brokerId) jsonError('Quote ID and broker ID are required', 400);
    if (!$actorId) jsonError('Actor ID is required for authentication', 401);

    $actor = requireAdminOrManager($actorId);
    if ($actor['role'] === 'manager' && !checkPermission($actorId, 'assignLeads')) {
        jsonError("You don't have permission to assign leads", 403);
    }

    $stmt = $db->prepare("SELECT * FROM quotes WHERE id = ?");
    $stmt->execute([$quoteId]);
    $quote = $stmt->fetch();
    if (!$quote) jsonError('Quote not found', 404);

    if ($quote['assigned_to'] === $brokerId) {
        $stmt = $db->prepare("SELECT balance FROM users WHERE id = ?");
        $stmt->execute([$brokerId]);
        $b = $stmt->fetch();
        jsonResponse(['success' => true, 'message' => 'Lead already assigned to this broker', 'newBalance' => $b['balance'], 'leadCost' => 0, 'alreadyAssigned' => true]);
    }

    $currentLeadCosts = getLeadCosts();

    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$brokerId]);
    $broker = $stmt->fetch();
    if (!$broker) jsonError('Broker not found', 404);
    if ($broker['role'] !== 'broker') jsonError('Can only assign leads to brokers', 400);
    if ($broker['status'] === 'paused') jsonError('Cannot assign leads to paused brokers', 400);

    $now = time();
    if ($broker['pause_start_date'] && $broker['pause_end_date']) {
        if ($now >= strtotime($broker['pause_start_date']) && $now <= strtotime($broker['pause_end_date'])) {
            jsonError('Cannot assign leads to brokers during their pause period', 400);
        }
    } elseif ($broker['pause_start_date'] && !$broker['pause_end_date']) {
        if ($now >= strtotime($broker['pause_start_date'])) {
            jsonError('Cannot assign leads to paused brokers', 400);
        }
    }

    $defaultCost = $currentLeadCosts[$quote['type']] ?? ($currentLeadCosts['General'] ?? 8);
    $leadCost = ($broker['lead_cost_override'] !== null && $broker['lead_cost_override'] !== '')
        ? floatval($broker['lead_cost_override'])
        : $defaultCost;

    $currentBalance = floatval($broker['balance']);
    if ($currentBalance < $leadCost) {
        jsonError('Insufficient balance', 400);
    }

    $newBalance = number_format($currentBalance - $leadCost, 2, '.', '');
    $stmt = $db->prepare("UPDATE users SET balance = ? WHERE id = ?");
    $stmt->execute([$newBalance, $brokerId]);

    $txId = uuid();
    $stmt = $db->prepare("INSERT INTO transactions (id, user_id, type, amount, balance_after, description, quote_id, actor_id, actor_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$txId, $brokerId, 'lead_deduction', '-' . number_format($leadCost, 2, '.', ''), $newBalance, "Lead assigned: {$quote['type']} - {$quote['client_name']} ({$quote['quote_number']})", $quoteId, $actorId, $actorName]);

    $stmt = $db->prepare("UPDATE quotes SET assigned_to = ?, assigned_at = NOW(), updated_at = NOW() WHERE id = ?");
    $stmt->execute([$brokerId, $quoteId]);

    $actId = uuid();
    $stmt = $db->prepare("INSERT INTO activities (id, quote_id, type, content, author) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$actId, $quoteId, 'assignment', "Lead assigned to {$broker['name']} (\${$leadCost} deducted)", $actorName]);

    if ($broker['email']) {
        $assignEmail = generateAssignmentEmail($broker['name'], $quote['client_name'], $quote['type'], $quote['email'] ?? '', $quote['phone'] ?? null, $actorName);
        sendEmail($broker['email'], $assignEmail['subject'], $assignEmail['html']);
    }

    $stmt = $db->prepare("SELECT * FROM quotes WHERE id = ?");
    $stmt->execute([$quoteId]);
    $updatedQuote = $stmt->fetch();

    $stmt = $db->prepare("SELECT * FROM transactions WHERE id = ?");
    $stmt->execute([$txId]);
    $tx = $stmt->fetch();

    jsonResponse(['success' => true, 'newBalance' => $newBalance, 'transaction' => camelRow($tx), 'leadCost' => $leadCost, 'quote' => camelRow($updatedQuote)]);

} elseif ($parts[0] === 'leads' && ($parts[1] ?? '') === 'check-expiry' && $method === 'POST') {
    $input = jsonInput();
    $actorId = $input['actorId'] ?? null;
    if (!$actorId) jsonError('Actor ID is required', 401);
    requireAdminOrManager($actorId);

    $expiryHoursSetting = getSetting('lead_expiry_hours');
    $expiryHours = $expiryHoursSetting ? floatval($expiryHoursSetting) : 24;
    $now = time();

    $stmt = $db->query("SELECT * FROM quotes WHERE assigned_to IS NOT NULL AND assigned_at IS NOT NULL AND status = 'New'");
    $allQuotes = $stmt->fetchAll();

    $expiredLeads = [];
    foreach ($allQuotes as $q) {
        $assignedTime = strtotime($q['assigned_at']);
        $expiryTime = $assignedTime + ($expiryHours * 3600);
        if ($now > $expiryTime) {
            $stmt = $db->prepare("UPDATE quotes SET status = 'Expired', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$q['id']]);
            $aId = uuid();
            $stmt = $db->prepare("INSERT INTO activities (id, quote_id, type, content, author) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$aId, $q['id'], 'system', "Lead expired - broker did not respond within {$expiryHours} hours", 'System']);
            $expiredLeads[] = $q['id'];
        }
    }
    jsonResponse(['success' => true, 'expiredCount' => count($expiredLeads), 'expiredLeads' => $expiredLeads]);

} elseif ($parts[0] === 'leads' && ($parts[1] ?? '') === 'reassign' && $method === 'POST') {
    $input = jsonInput();
    $quoteId   = $input['quoteId'] ?? null;
    $brokerId  = $input['brokerId'] ?? null;
    $actorId   = $input['actorId'] ?? null;
    $actorName = $input['actorName'] ?? 'Admin';

    if (!$quoteId || !$brokerId) jsonError('Quote ID and broker ID are required', 400);
    if (!$actorId) jsonError('Actor ID is required', 401);

    $actor = requireAdminOrManager($actorId);
    if ($actor['role'] === 'manager' && !checkPermission($actorId, 'assignLeads')) {
        jsonError("You don't have permission to reassign leads", 403);
    }

    $stmt = $db->prepare("SELECT * FROM quotes WHERE id = ?");
    $stmt->execute([$quoteId]);
    $quote = $stmt->fetch();
    if (!$quote) jsonError('Quote not found', 404);

    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$brokerId]);
    $broker = $stmt->fetch();
    if (!$broker || $broker['role'] !== 'broker') jsonError('Invalid broker', 400);
    if ($broker['status'] === 'paused') jsonError('Cannot reassign to paused brokers', 400);

    $currentLeadCosts = getLeadCosts();
    $defaultCost = $currentLeadCosts[$quote['type']] ?? ($currentLeadCosts['General'] ?? 8);
    $leadCost = ($broker['lead_cost_override'] !== null && $broker['lead_cost_override'] !== '')
        ? floatval($broker['lead_cost_override'])
        : $defaultCost;

    $currentBalance = floatval($broker['balance']);
    if ($currentBalance < $leadCost) {
        jsonResponse(['error' => 'Insufficient balance', 'required' => $leadCost, 'currentBalance' => $broker['balance']], 400);
    }

    $newBalance = number_format($currentBalance - $leadCost, 2, '.', '');
    $stmt = $db->prepare("UPDATE users SET balance = ? WHERE id = ?");
    $stmt->execute([$newBalance, $brokerId]);

    $txId = uuid();
    $stmt = $db->prepare("INSERT INTO transactions (id, user_id, type, amount, balance_after, description, quote_id, actor_id, actor_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$txId, $brokerId, 'lead_deduction', '-' . number_format($leadCost, 2, '.', ''), $newBalance, "Lead reassigned: {$quote['type']} - {$quote['client_name']} ({$quote['quote_number']})", $quoteId, $actorId, $actorName]);

    $stmt = $db->prepare("UPDATE quotes SET assigned_to = ?, assigned_at = NOW(), status = 'New', updated_at = NOW() WHERE id = ?");
    $stmt->execute([$brokerId, $quoteId]);

    $aId = uuid();
    $stmt = $db->prepare("INSERT INTO activities (id, quote_id, type, content, author) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$aId, $quoteId, 'assignment', "Lead reassigned to {$broker['name']} (\${$leadCost} deducted) by {$actorName}", $actorName]);

    if ($broker['email']) {
        $assignEmail = generateAssignmentEmail($broker['name'], $quote['client_name'], $quote['type'], $quote['email'] ?? '', $quote['phone'] ?? null, $actorName);
        sendEmail($broker['email'], $assignEmail['subject'], $assignEmail['html']);
    }

    $stmt = $db->prepare("SELECT * FROM transactions WHERE id = ?");
    $stmt->execute([$txId]);
    $tx = $stmt->fetch();

    jsonResponse(['success' => true, 'newBalance' => $newBalance, 'transaction' => camelRow($tx), 'leadCost' => $leadCost]);

} elseif ($parts[0] === 'contact' && $method === 'POST') {
    $input = jsonInput();
    $name     = $input['name'] ?? null;
    $email    = $input['email'] ?? null;
    $category = $input['category'] ?? null;
    $message  = $input['message'] ?? null;
    if (!$name || !$email || !$category || !$message) jsonError('All fields are required', 400);

    $categoryLabels = [
        'auto' => 'Auto Insurance', 'home' => 'Home Insurance', 'tenant' => 'Tenant Insurance',
        'travel' => 'Travel Insurance', 'life' => 'Life Insurance', 'business' => 'Business Insurance',
        'mortgage' => 'Mortgage', 'compare' => 'Compare Quotes', 'advertisement' => 'Advertisement Inquiry', 'other' => 'Other',
    ];
    $categoryLabel = $categoryLabels[$category] ?? $category;

    $html = "<h2>New Contact Form Submission</h2>
        <p><strong>Name:</strong> {$name}</p>
        <p><strong>Email:</strong> {$email}</p>
        <p><strong>Category:</strong> {$categoryLabel}</p>
        <p><strong>Message:</strong></p>
        <p>" . nl2br(htmlspecialchars($message)) . "</p>";

    sendEmail('info@quoteus.ca', "[QuoteUs.ca Contact] {$categoryLabel} - {$name}", $html);
    jsonResponse(['success' => true, 'message' => 'Contact form submitted successfully']);

} elseif ($parts[0] === 'activities' && !isset($parts[1]) && $method === 'POST') {
    $input = jsonInput();
    $id = uuid();
    $stmt = $db->prepare("INSERT INTO activities (id, quote_id, type, content, author) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$id, $input['quoteId'] ?? null, $input['type'] ?? 'note', $input['content'] ?? '', $input['author'] ?? 'System']);
    $stmt = $db->prepare("SELECT * FROM activities WHERE id = ?");
    $stmt->execute([$id]);
    jsonResponse(camelRow($stmt->fetch()), 201);

} elseif ($parts[0] === 'settings' && ($parts[1] ?? '') === 'lead-costs' && $method === 'GET') {
    jsonResponse(['costs' => getLeadCosts()]);

} elseif ($parts[0] === 'settings' && ($parts[1] ?? '') === 'lead-costs' && $method === 'POST') {
    $input = jsonInput();
    $actorId = $input['actorId'] ?? null;
    if (!$actorId) jsonError('Actor ID is required', 401);
    $actor = requireAdminOrManager($actorId);
    if ($actor['role'] === 'manager' && !checkPermission($actorId, 'editLeadCosts')) {
        jsonError("You don't have permission to edit lead costs", 403);
    }
    $costs = $input['costs'] ?? null;
    if (!$costs || !is_array($costs)) jsonError('Costs object is required', 400);
    setSetting('lead_costs', json_encode($costs), $actorId);
    jsonResponse(['success' => true, 'costs' => $costs]);

} elseif ($parts[0] === 'settings' && ($parts[1] ?? '') === 'lead-expiry-hours' && $method === 'GET') {
    $val = getSetting('lead_expiry_hours');
    jsonResponse(['hours' => $val ? floatval($val) : 24]);

} elseif ($parts[0] === 'settings' && ($parts[1] ?? '') === 'lead-expiry-hours' && $method === 'POST') {
    $input = jsonInput();
    $actorId = $input['actorId'] ?? null;
    if (!$actorId) jsonError('Actor ID is required', 401);
    requireAdminOrManager($actorId);
    $hours = $input['hours'] ?? null;
    if (!is_numeric($hours) || $hours < 1 || $hours > 720) jsonError('Hours must be between 1 and 720 (30 days)', 400);
    setSetting('lead_expiry_hours', strval($hours), $actorId);
    jsonResponse(['success' => true, 'hours' => $hours]);

} elseif ($parts[0] === 'settings' && ($parts[1] ?? '') === 'social-media' && $method === 'GET') {
    $val = getSetting('social_media');
    if ($val) {
        jsonResponse(json_decode($val, true));
    } else {
        jsonResponse([
            'facebook'  => 'https://www.facebook.com/people/QuoteUsca/100064074608534/',
            'instagram' => 'https://www.instagram.com/quoteus.ca/',
            'twitter'   => '',
            'linkedin'  => '',
            'youtube'   => '',
            'tiktok'    => '',
        ]);
    }

} elseif ($parts[0] === 'settings' && ($parts[1] ?? '') === 'custom-css' && $method === 'GET') {
    $val = getSetting('custom_css');
    jsonResponse(['value' => $val ?? '']);

} elseif ($parts[0] === 'settings' && ($parts[1] ?? '') === 'ads-per-slot' && $method === 'GET') {
    $val = getSetting('ads_per_slot');
    $parsed = $val ? intval($val) : 1;
    $clamped = max(1, min(3, $parsed));
    jsonResponse(['value' => $clamped]);

} elseif ($parts[0] === 'settings' && isset($parts[1]) && $method === 'GET') {
    $val = getSetting($parts[1]);
    jsonResponse(['value' => $val]);

} elseif ($parts[0] === 'settings' && isset($parts[1]) && $method === 'POST') {
    $input = jsonInput();
    $actorId = $input['actorId'] ?? null;
    if (!$actorId) jsonError('Actor ID is required', 401);
    requireAdminOrManager($actorId);
    setSetting($parts[1], $input['value'] ?? '', $actorId);
    jsonResponse(['success' => true]);

} elseif ($parts[0] === 'credits' && ($parts[1] ?? '') === 'packages' && $method === 'GET') {
    global $CREDIT_PACKAGES;
    jsonResponse(['packages' => $CREDIT_PACKAGES]);

} elseif ($parts[0] === 'credits' && isset($parts[1]) && ($parts[2] ?? '') === 'transactions' && $method === 'GET') {
    $stmt = $db->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$parts[1]]);
    jsonResponse(camelRows($stmt->fetchAll()));

} elseif ($parts[0] === 'credits' && isset($parts[1]) && !isset($parts[2]) && $method === 'GET') {
    $stmt = $db->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$parts[1]]);
    $user = $stmt->fetch();
    if (!$user) jsonError('User not found', 404);
    jsonResponse(['balance' => $user['balance']]);

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'credits' && ($parts[2] ?? '') === 'adjust' && $method === 'POST') {
    $input = jsonInput();
    $userId   = $input['userId'] ?? null;
    $amount   = $input['amount'] ?? null;
    $reason   = $input['reason'] ?? null;
    $actorId  = $input['actorId'] ?? null;
    $actorName = $input['actorName'] ?? null;

    if (!$userId || !$amount || !$reason) jsonError('User ID, amount, and reason are required', 400);
    if (!$actorId) jsonError('Actor ID is required for authentication', 401);

    $actor = requireAdminOrManager($actorId);
    if ($actor['role'] === 'manager' && !checkPermission($actorId, 'adjustBalances')) {
        jsonError("You don't have permission to adjust credit balances", 403);
    }

    $numAmount = floatval($amount);
    $stmt = $db->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    if (!$user) jsonError('User not found', 404);

    $currentBalance = floatval($user['balance']);
    $newBalance = number_format($currentBalance + $numAmount, 2, '.', '');
    $stmt = $db->prepare("UPDATE users SET balance = ? WHERE id = ?");
    $stmt->execute([$newBalance, $userId]);

    $type = $numAmount >= 0 ? 'manual_credit' : 'adjustment';
    $txId = uuid();
    $desc = ($numAmount >= 0 ? 'Manual credit' : 'Manual debit') . ": {$reason}";
    $stmt = $db->prepare("INSERT INTO transactions (id, user_id, type, amount, balance_after, description, reason, actor_id, actor_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$txId, $userId, $type, number_format(abs($numAmount), 2, '.', ''), $newBalance, $desc, $reason, $actorId, $actorName]);

    $stmt = $db->prepare("SELECT * FROM transactions WHERE id = ?");
    $stmt->execute([$txId]);
    $tx = $stmt->fetch();

    jsonResponse(['success' => true, 'newBalance' => $newBalance, 'transaction' => camelRow($tx)]);

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'transactions' && $method === 'GET') {
    $stmt = $db->query("SELECT * FROM transactions ORDER BY created_at DESC");
    jsonResponse(camelRows($stmt->fetchAll()));

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'settings' && isset($parts[2]) && $method === 'POST') {
    $input = jsonInput();
    $actorId = $input['actorId'] ?? null;
    if (!$actorId) jsonError('Actor ID is required', 401);
    requireAdminOrManager($actorId);
    $value = $input['value'] ?? '';
    if (is_array($value)) $value = json_encode($value);
    setSetting($parts[2], $value, $actorId);
    jsonResponse(['success' => true]);

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'settings' && isset($parts[2]) && $method === 'GET') {
    $val = getSetting($parts[2]);
    jsonResponse(['value' => $val]);

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'broker-lead-cost' && $method === 'POST') {
    $input = jsonInput();
    $brokerId = $input['brokerId'] ?? null;
    $leadCost = $input['leadCost'] ?? null;
    $actorId  = $input['actorId'] ?? null;

    if (!$brokerId) jsonError('Broker ID is required', 400);
    if (!$actorId) jsonError('Actor ID is required for authentication', 401);
    requireAdminOrManager($actorId);

    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$brokerId]);
    $broker = $stmt->fetch();
    if (!$broker) jsonError('Broker not found', 404);
    if ($broker['role'] !== 'broker') jsonError('Can only set lead costs for brokers', 400);

    $costValue = null;
    if ($leadCost !== null && $leadCost !== '') {
        $numCost = floatval($leadCost);
        if ($numCost < 0) jsonError('Lead cost must be $0 or higher', 400);
        $costValue = number_format($numCost, 2, '.', '');
    }

    $stmt = $db->prepare("UPDATE users SET lead_cost_override = ? WHERE id = ?");
    $stmt->execute([$costValue, $brokerId]);
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$brokerId]);
    jsonResponse(['success' => true, 'broker' => safeUser(camelRow($stmt->fetch()))]);

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'broker-profile' && $method === 'POST') {
    $input = jsonInput();
    $actorId  = $input['actorId'] ?? null;
    $brokerId = $input['brokerId'] ?? null;
    if (!$actorId) jsonError('Actor ID is required', 401);
    requireAdminOrManager($actorId);
    if (!$brokerId) jsonError('Broker ID is required', 400);

    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$brokerId]);
    $broker = $stmt->fetch();
    if (!$broker || $broker['role'] !== 'broker') jsonError('Broker not found', 404);

    $sets = [];
    $vals = [];
    if (isset($input['brokerTier'])) { $sets[] = "broker_tier = ?"; $vals[] = $input['brokerTier'] ?: null; }
    if (isset($input['preferredInsuranceTypes'])) { $sets[] = "preferred_insurance_types = ?"; $vals[] = json_encode($input['preferredInsuranceTypes']); }
    if (isset($input['preferredDemographics'])) { $sets[] = "preferred_demographics = ?"; $vals[] = $input['preferredDemographics']; }

    if (!empty($sets)) {
        $vals[] = $brokerId;
        $stmt = $db->prepare("UPDATE users SET " . implode(', ', $sets) . " WHERE id = ?");
        $stmt->execute($vals);
    }

    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$brokerId]);
    jsonResponse(['success' => true, 'broker' => safeUser(camelRow($stmt->fetch()))]);

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'broker-notes' && isset($parts[2]) && $method === 'GET') {
    $actorId = $_GET['actorId'] ?? null;
    if (!$actorId) jsonError('Actor ID is required', 401);
    requireAdminOrManager($actorId);
    $stmt = $db->prepare("SELECT * FROM broker_notes WHERE broker_id = ? ORDER BY created_at DESC");
    $stmt->execute([$parts[2]]);
    jsonResponse(camelRows($stmt->fetchAll()));

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'broker-notes' && !isset($parts[2]) && $method === 'POST') {
    $input = jsonInput();
    $actorId   = $input['actorId'] ?? null;
    $brokerId  = $input['brokerId'] ?? null;
    $content   = $input['content'] ?? null;
    $authorName = $input['authorName'] ?? null;
    if (!$actorId) jsonError('Actor ID is required', 401);
    $actor = requireAdminOrManager($actorId);
    if (!$brokerId || !$content) jsonError('Broker ID and content are required', 400);

    $id = uuid();
    $stmt = $db->prepare("INSERT INTO broker_notes (id, broker_id, author_id, author_name, content) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$id, $brokerId, $actorId, $authorName ?? $actor['name'], $content]);
    $stmt = $db->prepare("SELECT * FROM broker_notes WHERE id = ?");
    $stmt->execute([$id]);
    jsonResponse(camelRow($stmt->fetch()));

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'broker-notes' && isset($parts[2]) && $method === 'DELETE') {
    $actorId = $_GET['actorId'] ?? null;
    if (!$actorId) jsonError('Actor ID is required', 401);
    requireAdminOrManager($actorId);
    $stmt = $db->prepare("DELETE FROM broker_notes WHERE id = ?");
    $stmt->execute([$parts[2]]);
    jsonResponse(['success' => $stmt->rowCount() > 0]);

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'broker-stats' && isset($parts[2]) && $method === 'GET') {
    $actorId = $_GET['actorId'] ?? null;
    if (!$actorId) jsonError('Actor ID is required', 401);
    requireAdminOrManager($actorId);

    $brokerId = $parts[2];
    $stmt = $db->prepare("SELECT * FROM quotes WHERE assigned_to = ?");
    $stmt->execute([$brokerId]);
    $brokerQuotes = $stmt->fetchAll();

    $totalAssigned = count($brokerQuotes);
    $statuses = ['Bound' => 0, 'Win' => 0, 'Lose' => 0, 'Quoted' => 0, 'Lost' => 0, 'Closed' => 0, 'Contacted' => 0, 'Follow-Up' => 0, 'New' => 0];
    $byType = [];
    foreach ($brokerQuotes as $q) {
        if (isset($statuses[$q['status']])) $statuses[$q['status']]++;
        $byType[$q['type']] = ($byType[$q['type']] ?? 0) + 1;
    }
    $totalWins = $statuses['Bound'] + $statuses['Win'];
    $winRate = $totalAssigned > 0 ? number_format(($totalWins / $totalAssigned) * 100, 1) : '0.0';

    jsonResponse([
        'totalAssigned' => $totalAssigned,
        'bound'     => $statuses['Bound'],
        'win'       => $statuses['Win'],
        'lose'      => $statuses['Lose'],
        'quoted'    => $statuses['Quoted'],
        'lost'      => $statuses['Lost'],
        'closed'    => $statuses['Closed'],
        'contacted' => $statuses['Contacted'],
        'followUp'  => $statuses['Follow-Up'],
        'newLeads'  => $statuses['New'],
        'winRate'   => $winRate,
        'byType'    => $byType,
    ]);

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'email-report' && $method === 'POST') {
    $input = jsonInput();
    $actorId = $input['actorId'] ?? null;
    if (!$actorId) jsonError('Actor ID is required for authentication', 401);
    requireAdminOrManager($actorId);

    $subject = $input['subject'] ?? null;
    $body    = $input['body'] ?? null;
    $to      = $input['to'] ?? null;
    if (!$subject || !$body || !$to) jsonError('Missing required fields: subject, body, to', 400);

    $html = "<div style='font-family:Arial,sans-serif;padding:20px;max-width:600px;margin:0 auto;'>
        <div style='background:linear-gradient(135deg,#1e40af,#3b82f6);color:white;padding:24px;border-radius:12px 12px 0 0;'>
            <h1 style='margin:0;font-size:24px;'>QuoteUs.ca Report</h1>
            <p style='margin:8px 0 0;opacity:0.9;'>{$subject}</p>
        </div>
        <div style='background:#f8fafc;padding:24px;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 12px 12px;'>
            <pre style='white-space:pre-wrap;font-family:Arial,sans-serif;line-height:1.6;color:#334155;'>{$body}</pre>
            <hr style='border:none;border-top:1px solid #e2e8f0;margin:20px 0;'>
            <p style='color:#94a3b8;font-size:12px;text-align:center;'>Generated by QuoteUs.ca on " . date('Y-m-d') . "</p>
        </div>
    </div>";

    $sent = sendEmail($to, $subject, $html);
    if ($sent) {
        jsonResponse(['success' => true]);
    } else {
        jsonError('Failed to send email. Check SMTP configuration.', 500);
    }

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'redirects' && !isset($parts[2]) && $method === 'GET') {
    $stmt = $db->query("SELECT * FROM partner_redirects ORDER BY created_at DESC");
    jsonResponse(camelRows($stmt->fetchAll()));

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'redirects' && !isset($parts[2]) && $method === 'POST') {
    $input = jsonInput();
    $quoteType   = $input['quoteType'] ?? null;
    $redirectUrl = $input['redirectUrl'] ?? null;
    if (!$quoteType || !$redirectUrl) jsonError('Quote type and redirect URL are required', 400);

    $id = uuid();
    $stmt = $db->prepare("INSERT INTO partner_redirects (id, quote_type, redirect_url, is_active, description) VALUES (?, ?, ?, ?, ?)");
    try {
        $stmt->execute([$id, $quoteType, $redirectUrl, ($input['isActive'] ?? true) ? 1 : 0, $input['description'] ?? null]);
    } catch (\PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate') !== false || strpos($e->getMessage(), 'unique') !== false) {
            jsonError('A redirect for this quote type already exists', 400);
        }
        throw $e;
    }
    $stmt = $db->prepare("SELECT * FROM partner_redirects WHERE id = ?");
    $stmt->execute([$id]);
    jsonResponse(camelRow($stmt->fetch()));

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'redirects' && isset($parts[2]) && $method === 'PUT') {
    $input = jsonInput();
    $sets = [];
    $vals = [];
    foreach ($input as $col => $val) {
        $snake = strtolower(preg_replace('/[A-Z]/', '_$0', $col));
        $sets[] = "`{$snake}` = ?";
        $vals[] = $val;
    }
    $sets[] = "updated_at = NOW()";
    $vals[] = $parts[2];
    try {
        $stmt = $db->prepare("UPDATE partner_redirects SET " . implode(', ', $sets) . " WHERE id = ?");
        $stmt->execute($vals);
    } catch (\PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate') !== false || strpos($e->getMessage(), 'unique') !== false) {
            jsonError('A redirect for this quote type already exists', 400);
        }
        throw $e;
    }
    $stmt = $db->prepare("SELECT * FROM partner_redirects WHERE id = ?");
    $stmt->execute([$parts[2]]);
    $redirect = $stmt->fetch();
    if (!$redirect) jsonError('Redirect not found', 404);
    jsonResponse(camelRow($redirect));

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'redirects' && isset($parts[2]) && $method === 'DELETE') {
    $stmt = $db->prepare("DELETE FROM partner_redirects WHERE id = ?");
    $stmt->execute([$parts[2]]);
    if ($stmt->rowCount() === 0) jsonError('Redirect not found', 404);
    jsonResponse(['success' => true]);

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'advertisements' && ($parts[2] ?? '') === 'upload' && $method === 'POST') {
    if (empty($_FILES['file'])) jsonError('No file uploaded', 400);

    $file = $_FILES['file'];
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'video/mp4', 'video/webm', 'video/quicktime'];
    if (!in_array($file['type'], $allowedTypes)) jsonError('Only image and video files are allowed', 400);

    $uploadDir = __DIR__ . '/../uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $uniqueSuffix = time() . '-' . mt_rand(100000000, 999999999);
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = "ad-{$uniqueSuffix}.{$ext}";
    $destination = $uploadDir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        jsonError('Failed to save uploaded file', 500);
    }
    jsonResponse(['url' => "/uploads/{$filename}", 'filename' => $filename]);

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'advertisements' && !isset($parts[2]) && $method === 'GET') {
    $stmt = $db->query("SELECT * FROM advertisements ORDER BY created_at DESC");
    jsonResponse(camelRows($stmt->fetchAll()));

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'advertisements' && isset($parts[2]) && $method === 'GET') {
    $stmt = $db->prepare("SELECT * FROM advertisements WHERE id = ?");
    $stmt->execute([$parts[2]]);
    $ad = $stmt->fetch();
    if (!$ad) jsonError('Advertisement not found', 404);
    jsonResponse(camelRow($ad));

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'advertisements' && !isset($parts[2]) && $method === 'POST') {
    $input = jsonInput();
    if (empty($input['name']) || empty($input['mediaUrl'])) jsonError('Name and media URL are required', 400);

    $id = uuid();
    $previewToken = bin2hex(random_bytes(16));
    $stmt = $db->prepare("INSERT INTO advertisements (id, name, media_type, media_url, link_url, open_in_popup, target_pages, status, start_date, end_date, priority, created_by, preview_token, ad_text, text_color, background_color, text_position, top_text, center_text, bottom_text, top_text_color, center_text_color, bottom_text_color, top_bg_color, center_bg_color, bottom_bg_color) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $id,
        $input['name'],
        $input['mediaType'] ?? 'image',
        $input['mediaUrl'],
        $input['linkUrl'] ?? null,
        ($input['openInPopup'] ?? false) ? 1 : 0,
        json_encode($input['targetPages'] ?? []),
        $input['status'] ?? 'active',
        $input['startDate'] ?? null,
        $input['endDate'] ?? null,
        $input['priority'] ?? 1,
        $input['createdBy'] ?? null,
        $previewToken,
        $input['adText'] ?? null,
        $input['textColor'] ?? '#ffffff',
        $input['backgroundColor'] ?? '#1e3a5f',
        $input['textPosition'] ?? 'bottom',
        $input['topText'] ?? null,
        $input['centerText'] ?? null,
        $input['bottomText'] ?? null,
        $input['topTextColor'] ?? '#ffffff',
        $input['centerTextColor'] ?? '#ffffff',
        $input['bottomTextColor'] ?? '#ffffff',
        $input['topBgColor'] ?? '#1e3a5f',
        $input['centerBgColor'] ?? '#1e3a5f',
        $input['bottomBgColor'] ?? '#1e3a5f',
    ]);

    $stmt = $db->prepare("SELECT * FROM advertisements WHERE id = ?");
    $stmt->execute([$id]);
    jsonResponse(camelRow($stmt->fetch()), 201);

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'advertisements' && isset($parts[2]) && $method === 'PATCH') {
    $input = jsonInput();
    $fields = ['name', 'mediaType', 'mediaUrl', 'linkUrl', 'openInPopup', 'targetPages', 'status', 'startDate', 'endDate', 'priority', 'adText', 'textColor', 'backgroundColor', 'textPosition', 'topText', 'centerText', 'bottomText', 'topTextColor', 'centerTextColor', 'bottomTextColor', 'topBgColor', 'centerBgColor', 'bottomBgColor'];

    $sets = [];
    $vals = [];
    foreach ($fields as $field) {
        if (array_key_exists($field, $input)) {
            $snake = strtolower(preg_replace('/[A-Z]/', '_$0', $field));
            $sets[] = "`{$snake}` = ?";
            $val = $input[$field];
            if (is_array($val)) $val = json_encode($val);
            if (is_bool($val)) $val = $val ? 1 : 0;
            $vals[] = $val;
        }
    }
    $sets[] = "updated_at = NOW()";
    $vals[] = $parts[2];

    $stmt = $db->prepare("UPDATE advertisements SET " . implode(', ', $sets) . " WHERE id = ?");
    $stmt->execute($vals);
    $stmt = $db->prepare("SELECT * FROM advertisements WHERE id = ?");
    $stmt->execute([$parts[2]]);
    $ad = $stmt->fetch();
    if (!$ad) jsonError('Advertisement not found', 404);
    jsonResponse(camelRow($ad));

} elseif ($parts[0] === 'admin' && ($parts[1] ?? '') === 'advertisements' && isset($parts[2]) && $method === 'DELETE') {
    $stmt = $db->prepare("DELETE FROM advertisements WHERE id = ?");
    $stmt->execute([$parts[2]]);
    jsonResponse(['success' => true]);

} elseif ($parts[0] === 'advertisements' && ($parts[1] ?? '') === 'active' && $method === 'GET') {
    $page = $_GET['page'] ?? null;
    if (!$page) jsonError('Page parameter required', 400);

    $stmt = $db->query("SELECT * FROM advertisements WHERE status = 'active' AND (start_date IS NULL OR start_date <= NOW()) AND (end_date IS NULL OR end_date >= NOW()) ORDER BY priority DESC");
    $allAds = $stmt->fetchAll();

    $filtered = array_values(array_filter($allAds, function($ad) use ($page) {
        $targetPages = is_string($ad['target_pages']) ? json_decode($ad['target_pages'], true) : ($ad['target_pages'] ?? []);
        if (empty($targetPages)) return true;
        return in_array($page, $targetPages) || in_array('all', $targetPages);
    }));
    jsonResponse(camelRows($filtered));

} elseif ($parts[0] === 'advertisements' && ($parts[1] ?? '') === 'preview' && isset($parts[2]) && ($parts[3] ?? '') === 'approve' && $method === 'POST') {
    $input = jsonInput();
    $stmt = $db->prepare("SELECT * FROM advertisements WHERE preview_token = ?");
    $stmt->execute([$parts[2]]);
    $ad = $stmt->fetch();
    if (!$ad) jsonError('Advertisement not found', 404);

    $approved = $input['approved'] ?? false;
    $stmt = $db->prepare("UPDATE advertisements SET approval_status = ?, status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([
        $approved ? 'approved' : 'rejected',
        $approved ? 'active' : 'paused',
        $ad['id'],
    ]);
    $stmt = $db->prepare("SELECT * FROM advertisements WHERE id = ?");
    $stmt->execute([$ad['id']]);
    jsonResponse(camelRow($stmt->fetch()));

} elseif ($parts[0] === 'advertisements' && ($parts[1] ?? '') === 'preview' && isset($parts[2]) && $method === 'GET') {
    $stmt = $db->prepare("SELECT * FROM advertisements WHERE preview_token = ?");
    $stmt->execute([$parts[2]]);
    $ad = $stmt->fetch();
    if (!$ad) jsonError('Advertisement not found', 404);
    jsonResponse(camelRow($ad));

} elseif ($parts[0] === 'advertisements' && isset($parts[1]) && ($parts[2] ?? '') === 'impression' && $method === 'POST') {
    $stmt = $db->prepare("UPDATE advertisements SET impressions = impressions + 1 WHERE id = ?");
    $stmt->execute([$parts[1]]);
    jsonResponse(['success' => true]);

} elseif ($parts[0] === 'advertisements' && isset($parts[1]) && ($parts[2] ?? '') === 'click' && $method === 'POST') {
    $stmt = $db->prepare("UPDATE advertisements SET clicks = clicks + 1 WHERE id = ?");
    $stmt->execute([$parts[1]]);
    jsonResponse(['success' => true]);

} elseif ($parts[0] === 'ads' && isset($parts[1]) && ($parts[2] ?? '') === 'impression' && $method === 'POST') {
    $stmt = $db->prepare("UPDATE advertisements SET impressions = impressions + 1 WHERE id = ?");
    $stmt->execute([$parts[1]]);
    jsonResponse(['success' => true]);

} elseif ($parts[0] === 'ads' && isset($parts[1]) && ($parts[2] ?? '') === 'click' && $method === 'POST') {
    $stmt = $db->prepare("UPDATE advertisements SET clicks = clicks + 1 WHERE id = ?");
    $stmt->execute([$parts[1]]);
    jsonResponse(['success' => true]);

} elseif ($parts[0] === 'ads' && isset($parts[1]) && $method === 'GET') {
    $page = $parts[1];
    $stmt = $db->query("SELECT * FROM advertisements WHERE status = 'active' AND (start_date IS NULL OR start_date <= NOW()) AND (end_date IS NULL OR end_date >= NOW()) ORDER BY priority DESC");
    $allAds = $stmt->fetchAll();

    $filtered = array_values(array_filter($allAds, function($ad) use ($page) {
        $targetPages = is_string($ad['target_pages']) ? json_decode($ad['target_pages'], true) : ($ad['target_pages'] ?? []);
        if (empty($targetPages)) return true;
        return in_array($page, $targetPages) || in_array('all', $targetPages);
    }));
    jsonResponse(camelRows($filtered));

} elseif ($parts[0] === 'redirects' && isset($parts[1]) && $method === 'GET') {
    $stmt = $db->prepare("SELECT * FROM partner_redirects WHERE quote_type = ? AND is_active = 1 LIMIT 1");
    $stmt->execute([$parts[1]]);
    $redirect = $stmt->fetch();
    if (!$redirect) {
        jsonResponse(['redirectUrl' => null]);
    } else {
        jsonResponse(['redirectUrl' => $redirect['redirect_url']]);
    }

} else {
    jsonError('Route not found: ' . implode('/', $parts) . ' [' . $method . ']', 404);
}
