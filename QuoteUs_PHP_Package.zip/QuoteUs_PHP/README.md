# QuoteUs.ca - PHP/MySQL Package
# Updated: March 2, 2026

## Quick Start (3 Steps)

### Step 1: Upload Files
Upload ALL files (including hidden .htaccess files) to your public_html directory.

### Step 2: Database Setup
1. Create a MySQL database in cPanel (e.g., quoteus_db)
2. Create a database user and assign ALL PRIVILEGES
3. In phpMyAdmin, import these files in order:
   - `database/schema.sql` (creates tables)
   - `database/seed.sql` (loads data)

### Step 3: Configure Database
Copy `.env.example` to `.env` and fill in your database credentials:
```
DB_HOST=localhost
DB_PORT=3306
DB_NAME=your_database_name
DB_USER=your_database_user
DB_PASS=your_database_password
SITE_URL=https://yourdomain.com
```

### Test Your Setup
Visit `https://yourdomain.com/api/test.php` to verify:
- PHP version and extensions
- Database connection
- File permissions
- Table counts

### Default Login Credentials
- Admin: admin@quoteus.ca / password123
- Manager: manager@quoteus.ca / password123
- Broker: john@quoteus.ca / password123
- Broker: sarah@quoteus.ca / password123

**Change all passwords after first login!**

## Troubleshooting

### "Cannot access database" or blank pages
1. Visit `/api/test.php` to check database connection
2. Verify `.env` file has correct credentials
3. Check `error.log` in root directory for details

### API returns 404 for all requests
1. Make sure `.htaccess` files were uploaded (they are hidden files)
2. Verify Apache mod_rewrite is enabled
3. In cPanel, check that "AllowOverride All" is set

### Pages show 404 on refresh
The `.htaccess` in root handles SPA routing. If missing, page refreshes won't work.

### Upload permissions error
Set the `uploads/` directory permissions to 755:
```
chmod 755 uploads/
```

## Important Files
```
.htaccess              <- ROOT: Routes /api/* and SPA fallback (REQUIRED)
.env                   <- Your database credentials (create from .env.example)
api/
  .htaccess            <- API: Routes all requests to index.php (REQUIRED)
  index.php            <- All API endpoints
  test.php             <- Database connection tester
includes/
  config.php           <- Configuration loader
  db.php               <- PDO database connection
  email.php            <- SMTP email functions
database/
  schema.sql           <- Table definitions
  seed.sql             <- Data export
```
