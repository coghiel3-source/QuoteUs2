<?php
require_once __DIR__ . '/db.php';

function getSmtpSettings(): ?array {
    $db = getDB();
    $stmt = $db->prepare("SELECT value FROM system_settings WHERE `key` = 'smtp_settings'");
    $stmt->execute();
    $row = $stmt->fetch();
    if (!$row) return null;
    return json_decode($row['value'], true);
}

function sendEmail(string $to, string $subject, string $html): bool {
    $smtp = getSmtpSettings();
    if (!$smtp) {
        error_log("[Email] No SMTP settings configured - To: $to, Subject: $subject");
        return false;
    }

    try {
        require_once __DIR__ . '/PHPMailer/PHPMailer.php';
        require_once __DIR__ . '/PHPMailer/SMTP.php';
        require_once __DIR__ . '/PHPMailer/Exception.php';

        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = $smtp['host'];
        $mail->Port = intval($smtp['port']);
        $mail->SMTPAuth = true;
        $mail->Username = $smtp['username'];
        $mail->Password = $smtp['password'];
        $mail->SMTPSecure = ($smtp['useSsl'] && $smtp['port'] == 465) ? 'ssl' : 'tls';
        $mail->setFrom($smtp['fromEmail'], $smtp['fromName']);
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $html;
        $mail->send();
        return true;
    } catch (\Exception $e) {
        error_log("[Email] Error: " . $e->getMessage());
        return false;
    }
}

function generateNewLeadEmail(string $clientName, string $type, string $email, ?string $phone = null, string $source = 'Website'): array {
    $phoneRow = $phone ? "<tr><td style='padding:8px 0;color:#6b7280;'>Phone:</td><td style='padding:8px 0;color:#1f2937;'>$phone</td></tr>" : '';
    return [
        'subject' => "New $type Insurance Lead - $clientName",
        'html' => "<div style='font-family:Arial,sans-serif;max-width:600px;margin:0 auto;'>
            <div style='background-color:#16a34a;color:white;padding:20px;text-align:center;'><h1 style='margin:0;'>QuoteUs.ca</h1></div>
            <div style='padding:30px;background-color:#f9fafb;'>
                <h2 style='color:#1f2937;margin-top:0;'>New Lead Received</h2>
                <p style='color:#4b5563;'>A new insurance lead has been submitted.</p>
                <div style='background:white;border-radius:8px;padding:20px;margin:20px 0;'>
                    <table style='width:100%;border-collapse:collapse;'>
                        <tr><td style='padding:8px 0;color:#6b7280;width:120px;'>Client Name:</td><td style='padding:8px 0;color:#1f2937;font-weight:bold;'>$clientName</td></tr>
                        <tr><td style='padding:8px 0;color:#6b7280;'>Type:</td><td style='padding:8px 0;color:#1f2937;font-weight:bold;'>$type</td></tr>
                        <tr><td style='padding:8px 0;color:#6b7280;'>Email:</td><td style='padding:8px 0;color:#1f2937;'>$email</td></tr>
                        $phoneRow
                        <tr><td style='padding:8px 0;color:#6b7280;'>Source:</td><td style='padding:8px 0;color:#1f2937;'>$source</td></tr>
                    </table>
                </div>
                <a href='https://quoteus.ca/admin' style='display:inline-block;background:#16a34a;color:white;padding:12px 24px;text-decoration:none;border-radius:6px;'>View in CRM</a>
            </div>
        </div>"
    ];
}

function generateAssignmentEmail(string $brokerName, string $clientName, string $type, string $email, ?string $phone, string $assignedBy): array {
    $phoneRow = $phone ? "<tr><td style='padding:8px 0;color:#6b7280;'>Phone:</td><td style='padding:8px 0;color:#1f2937;'>$phone</td></tr>" : '';
    return [
        'subject' => "Lead Assigned: $clientName - $type Insurance",
        'html' => "<div style='font-family:Arial,sans-serif;max-width:600px;margin:0 auto;'>
            <div style='background-color:#16a34a;color:white;padding:20px;text-align:center;'><h1 style='margin:0;'>QuoteUs.ca</h1></div>
            <div style='padding:30px;background-color:#f9fafb;'>
                <h2 style='color:#1f2937;margin-top:0;'>Lead Assigned to You</h2>
                <p style='color:#4b5563;'>Hi $brokerName, a new lead has been assigned to you by $assignedBy.</p>
                <div style='background:white;border-radius:8px;padding:20px;margin:20px 0;'>
                    <table style='width:100%;border-collapse:collapse;'>
                        <tr><td style='padding:8px 0;color:#6b7280;width:120px;'>Client:</td><td style='padding:8px 0;color:#1f2937;font-weight:bold;'>$clientName</td></tr>
                        <tr><td style='padding:8px 0;color:#6b7280;'>Type:</td><td style='padding:8px 0;color:#1f2937;font-weight:bold;'>$type</td></tr>
                        <tr><td style='padding:8px 0;color:#6b7280;'>Email:</td><td style='padding:8px 0;color:#1f2937;'>$email</td></tr>
                        $phoneRow
                    </table>
                </div>
                <a href='https://quoteus.ca/admin' style='display:inline-block;background:#16a34a;color:white;padding:12px 24px;text-decoration:none;border-radius:6px;'>View Lead</a>
            </div>
        </div>"
    ];
}

function generateThankYouEmail(string $clientName, string $type): array {
    $typeLower = strtolower($type);
    return [
        'subject' => "Thank You for Your $type Insurance Inquiry - QuoteUs.ca",
        'html' => "<div style='font-family:Arial,sans-serif;max-width:600px;margin:0 auto;'>
            <div style='background-color:#16a34a;color:white;padding:20px;text-align:center;'><h1 style='margin:0;'>QuoteUs.ca</h1></div>
            <div style='padding:30px;background-color:#f9fafb;'>
                <h2 style='color:#1f2937;margin-top:0;'>Thank You, $clientName!</h2>
                <p style='color:#4b5563;font-size:18px;'>Thank you for your <strong>$type Insurance</strong> inquiry.</p>
                <p style='color:#4b5563;font-size:16px;'>You will be contacted shortly by a <strong>top-rated insurance broker</strong>.</p>
                <div style='background:white;border-radius:8px;padding:20px;margin:20px 0;border-left:4px solid #16a34a;'>
                    <p style='color:#1f2937;margin:0;font-weight:bold;'>What happens next?</p>
                    <ul style='color:#4b5563;margin-top:10px;'>
                        <li>A top-rated broker will review your inquiry</li>
                        <li>You'll receive a call or email shortly</li>
                        <li>We'll help you find the best $typeLower insurance coverage</li>
                    </ul>
                </div>
                <p style='color:#4b5563;margin-top:20px;'>Best regards,<br><strong>The QuoteUs.ca Team</strong></p>
            </div>
            <div style='padding:20px;text-align:center;color:#6b7280;font-size:14px;background:#f3f4f6;'>
                <p style='margin:0 0 8px;'>Need help? Contact us:</p>
                <p style='margin:0;font-weight:bold;'>1-877-253-2695</p>
                <p style='margin:8px 0 0;'>or email <a href='mailto:quote@quoteus.ca' style='color:#16a34a;'>quote@QuoteUs.ca</a></p>
            </div>
        </div>"
    ];
}

function generatePasswordResetEmail(string $userName, string $resetLink): array {
    return [
        'subject' => "Password Reset Request - QuoteUs.ca",
        'html' => "<div style='font-family:Arial,sans-serif;max-width:600px;margin:0 auto;'>
            <div style='background-color:#16a34a;color:white;padding:20px;text-align:center;'><h1 style='margin:0;'>QuoteUs.ca</h1></div>
            <div style='padding:30px;background-color:#f9fafb;'>
                <h2 style='color:#1f2937;margin-top:0;'>Password Reset Request</h2>
                <p style='color:#4b5563;'>Hello $userName,</p>
                <p style='color:#4b5563;'>Click the button below to reset your password:</p>
                <div style='text-align:center;margin:30px 0;'>
                    <a href='$resetLink' style='display:inline-block;background:#16a34a;color:white;padding:14px 28px;text-decoration:none;border-radius:8px;font-weight:bold;font-size:16px;'>Reset Password</a>
                </div>
                <p style='color:#4b5563;font-size:14px;'>This link expires in 1 hour.</p>
                <p style='color:#4b5563;margin-top:20px;'>Best regards,<br><strong>The QuoteUs.ca Team</strong></p>
            </div>
        </div>"
    ];
}
