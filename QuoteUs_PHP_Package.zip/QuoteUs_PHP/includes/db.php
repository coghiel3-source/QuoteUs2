<?php
require_once __DIR__ . '/config.php';

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (\PDOException $e) {
            error_log("QuoteUs DB Error: " . $e->getMessage());
            throw $e;
        }
    }
    return $pdo;
}

function uuid(): string {
    return sprintf(
        '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

function jsonInput(): array {
    $raw = file_get_contents('php://input');
    return json_decode($raw, true) ?? [];
}

function snakeToCamel(string $str): string {
    return lcfirst(str_replace('_', '', ucwords($str, '_')));
}

$JSON_COLUMNS = ['target_pages', 'preferred_insurance_types', 'product_types', 'permissions', 'assigned_postal_codes', 'assigned_cities', 'details'];
$BOOL_COLUMNS = ['open_in_popup', 'is_active'];

function camelRow(?array $row): ?array {
    if ($row === null || $row === false) return null;
    global $JSON_COLUMNS, $BOOL_COLUMNS;
    $result = [];
    foreach ($row as $key => $value) {
        if (in_array($key, $JSON_COLUMNS) && is_string($value) && $value !== '') {
            $decoded = json_decode($value, true);
            if ($decoded !== null) $value = $decoded;
        }
        if (in_array($key, $BOOL_COLUMNS)) {
            $value = (bool)$value;
        }
        $result[snakeToCamel($key)] = $value;
    }
    return $result;
}

function camelRows(array $rows): array {
    return array_map('camelRow', $rows);
}

function jsonResponse($data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function jsonError(string $message, int $status = 400): void {
    jsonResponse(['error' => $message], $status);
}

function hashPassword(string $password): string {
    return password_hash($password, PASSWORD_BCRYPT);
}

function verifyPassword(string $password, string $hash): bool {
    if (password_verify($password, $hash)) {
        return true;
    }
    return $password === $hash;
}
