import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { serveStatic } from "./static";
import { createServer } from "http";
import { runMigrations } from "stripe-replit-sync";
import { getStripeSync } from "./stripeClient";
import { WebhookHandlers } from "./webhookHandlers";
import { setupGoogleAuth } from "./googleAuth";
import { seoDirectives, sitemapXml } from "./seo";

const app = express();
const httpServer = createServer(app);

// Headers precede all API, upload, object and token route handlers.
app.use(seoDirectives);
app.get("/sitemap.xml", (_req, res) => res.type("application/xml").send(sitemapXml()));

declare module "http" {
  interface IncomingMessage {
    rawBody: unknown;
  }
}

// Initialize Stripe schema and sync on startup
async function initStripe() {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    console.log('[Stripe] No DATABASE_URL, skipping Stripe initialization');
    return;
  }

  try {
    console.log('[Stripe] Initializing schema...');
    await runMigrations({ databaseUrl });
    console.log('[Stripe] Schema ready');

    const stripeSync = await getStripeSync();
    
    const domains = process.env.REPLIT_DOMAINS?.split(',')[0];
    const webhookBaseUrl = process.env.APP_BASE_URL
      ? process.env.APP_BASE_URL.replace(/\/$/, "")
      : domains
      ? `https://${domains}`
      : null;
    if (webhookBaseUrl) {
      console.log('[Stripe] Setting up managed webhook...');
      await stripeSync.findOrCreateManagedWebhook(`${webhookBaseUrl}/api/stripe/webhook`);
      console.log('[Stripe] Webhook configured');
    }

    // Sync backfill in background
    stripeSync.syncBackfill()
      .then(() => console.log('[Stripe] Data synced'))
      .catch((err: any) => console.error('[Stripe] Sync error:', err));
  } catch (error) {
    console.error('[Stripe] Initialization error:', error);
  }
}

// Initialize Stripe (don't await - let server start)
initStripe();

// Register Stripe webhook route BEFORE express.json()
app.post(
  '/api/stripe/webhook',
  express.raw({ type: 'application/json' }),
  async (req, res) => {
    const signature = req.headers['stripe-signature'];
    if (!signature) {
      return res.status(400).json({ error: 'Missing stripe-signature' });
    }

    try {
      const sig = Array.isArray(signature) ? signature[0] : signature;
      if (!Buffer.isBuffer(req.body)) {
        console.error('[Stripe Webhook] Body is not a Buffer');
        return res.status(500).json({ error: 'Webhook processing error' });
      }
      await WebhookHandlers.processWebhook(req.body as Buffer, sig);
      res.status(200).json({ received: true });
    } catch (error: any) {
      console.error('[Stripe Webhook] Error:', error.message);
      res.status(400).json({ error: 'Webhook processing error' });
    }
  }
);

// Serve uploaded files (ads, etc.) directly from the uploads directory
import path from "path";
const uploadsDir = path.join(process.cwd(), "client", "public", "uploads");
app.use("/uploads", express.static(uploadsDir, {
  setHeaders: (res, filePath) => {
    if (filePath.startsWith(path.join(uploadsDir, "doc-signatures") + path.sep)) {
      res.setHeader("Cache-Control", "private, no-store");
    }
  },
}));
// Missing legacy uploads must not fall through to the SPA's HTML catch-all.
app.use("/uploads", (_req, res) => res.status(404).json({ error: "Upload not found" }));

// Serve downloadable PHP zip
const phpZipPath = path.join(process.cwd(), "QuoteUs_PHP_1.zip");
app.get("/download/QuoteUs_PHP_1.zip", (_req, res) => {
  res.download(phpZipPath, "QuoteUs_PHP_1.zip", (err) => {
    if (err) res.status(404).json({ error: "Zip file not found" });
  });
});

// Now apply JSON middleware for all other routes
app.use(
  express.json({
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  }),
);

app.use(express.urlencoded({ extended: false }));

// Setup Google OAuth for customers
setupGoogleAuth(app);

export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  console.log(`${formattedTime} [${source}] ${message}`);
}

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  await registerRoutes(httpServer, app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (process.env.NODE_ENV === "production") {
    serveStatic(app);
  } else {
    const { setupVite } = await import("./vite");
    await setupVite(httpServer, app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || "5000", 10);
  // `reusePort` (SO_REUSEPORT) is used on Replit but throws ENOTSUP on many
  // managed/shared hosts and some kernels. Only enable it on Replit.
  const listenOptions: { port: number; host: string; reusePort?: boolean } = {
    port,
    host: process.env.HOST || "0.0.0.0",
  };
  if (process.env.REPLIT_DOMAINS || process.env.REPLIT_DEV_DOMAIN) {
    listenOptions.reusePort = true;
  }
  httpServer.listen(listenOptions, () => {
    log(`serving on port ${port}`);
  });
})();
