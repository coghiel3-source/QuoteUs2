import { type Express } from "express";
import { createServer as createViteServer, createLogger } from "vite";
import { type Server } from "http";
import viteConfig from "../vite.config";
import fs from "fs";
import path from "path";
import { nanoid } from "nanoid";
import { redirectIndexHtml, renderPageHtml } from "./seo";
import { classifyPage } from "../shared/seo";

const viteLogger = createLogger();

export async function setupVite(server: Server, app: Express) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server, path: "/vite-hmr" },
    allowedHosts: true as const,
  };

  const vite = await createViteServer({
    ...viteConfig,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      },
    },
    server: serverOptions,
    appType: "custom",
  });

  app.use(redirectIndexHtml);
  app.use(vite.middlewares);

  app.use(async (req, res, next) => {
    const url = req.originalUrl;
    if (!["GET", "HEAD"].includes(req.method) || /^\/(?:api|uploads|objects)(?:\/|$)/.test(req.path) || /\.[^/]+$/.test(req.path)) {
      res.setHeader("X-Robots-Tag", "noindex, nofollow");
      return res.status(404).end();
    }

    try {
      const clientTemplate = path.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html",
      );

      // always reload the index.html file from disk incase it changes
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`,
      );
      const page = await vite.transformIndexHtml(url, template);
      let content: string | undefined;
      if (classifyPage(req.path) === "public" && !(req.path === "/rent-clock" && req.query.embed === "1")) {
        const { renderPublicPage } = await vite.ssrLoadModule("/src/entry-server.tsx");
        content = renderPublicPage(req.path);
      }
      const rendered = renderPageHtml(page, req.path, content);
      if (rendered.robots) res.setHeader("X-Robots-Tag", rendered.robots);
      res.status(rendered.status).set({ "Content-Type": "text/html" }).end(rendered.html);
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });
}
