import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { apiRequest } from './api';

export interface ManagerPermissions {
  viewLeads?: boolean;
  assignLeads?: boolean;
  manageBrokers?: boolean;
  viewCredits?: boolean;
  adjustBalances?: boolean;
  viewSettings?: boolean;
  viewLeadCosts?: boolean;
  editLeadCosts?: boolean;
  viewRgLeads?: boolean;
  manageRgLeads?: boolean;
  viewCommission?: boolean;
}

export interface RgPermissions {
  canAddLocations?: boolean;
  canEditLocations?: boolean;
  canAddTenants?: boolean;
  canRequestDocs?: boolean;
  canViewPricing?: boolean;
  canEditPricing?: boolean;
  canManageReminders?: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: 'admin' | 'manager' | 'partner' | 'broker' | 'customer' | 'rep';
  status: 'pending' | 'active' | 'denied' | 'paused' | 'cancelled';
  password?: string;
  balance?: string;
  stripeCustomerId?: string;
  brokerage?: string;
  yearsOfService?: number;
  productTypes?: string[];
  leadCostOverride?: string;
  permissions?: ManagerPermissions & { rg?: RgPermissions };
  createdAt?: string;
  lastLogin?: string;
  pauseStartDate?: string;
  pauseEndDate?: string;
  twoFactorEnabled?: boolean;
  performance?: {
    conversionRate: number;
    responseTime: string;
  };
}

interface AuthContextType {
  user: User | null;
  users: User[];
  loading: boolean;
  pendingTwoFactor: { userId: string; previewCode?: string } | null;
  login: (email: string, role: 'admin' | 'manager' | 'broker' | 'customer' | 'rep', password?: string) => Promise<boolean | 'twoFactor'>;
  verifyTwoFactor: (token: string) => Promise<boolean>;
  loginWithGoogle: (userId: string) => Promise<boolean>;
  logout: () => void;
  register: (name: string, email: string, password?: string, role?: 'broker' | 'customer' | 'manager' | 'admin', phone?: string, brokerFields?: { brokerage?: string; yearsOfService?: number; productTypes?: string[] }) => Promise<void>;
  approveBroker: (id: string) => Promise<void>;
  denyBroker: (id: string) => Promise<void>;
  updateUser: (id: string, data: Partial<User>) => Promise<void>;
  resetPassword: (id: string, newPassword: string) => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Auto-logout after this much inactivity (2 hours)
const INACTIVITY_LIMIT_MS = 2 * 60 * 60 * 1000;
const LAST_ACTIVITY_KEY = 'quoteus_last_activity';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [users, setUsers] = useState<User[]>([]);
  // Keep the first browser render identical to the server render. Restore the
  // stored session after hydration, before any persistence effects can clear it.
  const [user, setUser] = useState<User | null>(null);
  const [sessionRestored, setSessionRestored] = useState(false);
  const [loading, setLoading] = useState(true);
  const [seeded, setSeeded] = useState(false);
  const [pendingTwoFactor, setPendingTwoFactor] = useState<{ userId: string; previewCode?: string } | null>(null);
  // Seed database with initial users
  const seedUsers = async () => {
    try {
      const initialUsers = [
        { 
          name: 'Account Manager', 
          email: 'admin@quoteus.ca', 
          role: 'admin' as const, 
          status: 'active' as const, 
          password: 'password123',
          phone: '416-555-0100',
        },
        { 
          name: 'Sales Director', 
          email: 'manager@quoteus.ca', 
          role: 'manager' as const, 
          status: 'active' as const, 
          password: 'password123',
          phone: '416-555-0101',
        },
        { 
          name: 'John Broker', 
          email: 'john@quoteus.ca', 
          role: 'broker' as const, 
          status: 'active' as const, 
          password: 'password123',
          phone: '416-555-0102',
        },
        { 
          name: 'Sarah Agent', 
          email: 'sarah@quoteus.ca', 
          role: 'broker' as const, 
          status: 'pending' as const, 
          password: 'password123',
          phone: '416-555-0103',
        },
      ];

      for (const userData of initialUsers) {
        try {
          await apiRequest('/users', {
            method: 'POST',
            body: JSON.stringify(userData),
          });
        } catch (e) {
          // User might already exist, skip
        }
      }
      setSeeded(true);
      localStorage.setItem('quoteus_seeded', 'true');
    } catch (error) {
      console.error('Failed to seed users:', error);
    }
  };

  // Fetch all users from API
  const fetchUsers = async () => {
    try {
      const data = await apiRequest<User[]>('/users');
      setUsers(data);
    } catch (error) {
      console.error('Failed to fetch users:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    try {
      const saved = localStorage.getItem('quoteus_user');
      if (saved) {
        const last = parseInt(localStorage.getItem(LAST_ACTIVITY_KEY) || '0', 10);
        if (last && Date.now() - last > INACTIVITY_LIMIT_MS) {
          localStorage.removeItem('quoteus_user');
          localStorage.removeItem(LAST_ACTIVITY_KEY);
        } else {
          setUser(JSON.parse(saved));
        }
      }
    } catch {
      // An invalid/unavailable stored session is treated as signed out.
    } finally {
      setSessionRestored(true);
    }
  }, []);

  useEffect(() => {
    if (!sessionRestored) return;
    if (user) {
      const { password, ...safeUser } = user as any;
      localStorage.setItem('quoteus_user', JSON.stringify(safeUser));
    } else {
      localStorage.removeItem('quoteus_user');
    }
  }, [user, sessionRestored]);

  // Auto-logout after 2 hours of inactivity
  useEffect(() => {
    if (!sessionRestored) return;
    if (!user) {
      localStorage.removeItem(LAST_ACTIVITY_KEY);
      return;
    }

    const doLogout = () => {
      setUser(null);
      setPendingTwoFactor(null);
      localStorage.removeItem('quoteus_user');
      localStorage.removeItem(LAST_ACTIVITY_KEY);
    };

    // Returns true if the session has expired (and logs out). Always check
    // BEFORE recording new activity, so returning to a suspended tab after
    // the limit logs out instead of silently renewing the session.
    const isExpired = () => {
      const last = parseInt(localStorage.getItem(LAST_ACTIVITY_KEY) || '0', 10);
      if (last && Date.now() - last > INACTIVITY_LIMIT_MS) {
        doLogout();
        return true;
      }
      return false;
    };

    localStorage.setItem(LAST_ACTIVITY_KEY, String(Date.now()));

    let lastRecorded = Date.now();
    const recordActivity = () => {
      if (isExpired()) return;
      const now = Date.now();
      // Throttle writes to once per 30 seconds
      if (now - lastRecorded > 30 * 1000) {
        lastRecorded = now;
        localStorage.setItem(LAST_ACTIVITY_KEY, String(now));
      }
    };

    const events: (keyof WindowEventMap)[] = ['mousemove', 'mousedown', 'keydown', 'scroll', 'touchstart', 'click'];
    events.forEach((e) => window.addEventListener(e, recordActivity, { passive: true }));

    // Re-check when the tab regains focus/visibility (timers are throttled in background tabs)
    const onVisible = () => {
      if (document.visibilityState === 'visible') isExpired();
    };
    window.addEventListener('focus', onVisible);
    document.addEventListener('visibilitychange', onVisible);

    // Keep tabs in sync: if another tab logs out (removes the stored user), log out here too
    const onStorage = (e: StorageEvent) => {
      if (e.key === 'quoteus_user' && e.newValue === null) {
        setUser(null);
        setPendingTwoFactor(null);
      }
    };
    window.addEventListener('storage', onStorage);

    const interval = setInterval(isExpired, 60 * 1000);

    return () => {
      events.forEach((e) => window.removeEventListener(e, recordActivity));
      window.removeEventListener('focus', onVisible);
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('storage', onStorage);
      clearInterval(interval);
    };
  }, [user, sessionRestored]);

  useEffect(() => {
    const initializeAuth = async () => {
      const hasSeeded = localStorage.getItem('quoteus_seeded');
      if (!hasSeeded) {
        await seedUsers();
      }
      await fetchUsers();
    };

    initializeAuth();
  }, []);

  const login = async (email: string, role: 'admin' | 'manager' | 'broker' | 'customer' | 'rep', password?: string): Promise<boolean | 'twoFactor'> => {
    try {
      const response = await apiRequest<any>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, role, password }),
      });

      if (!response) {
        return false;
      }

      // 2FA required — hold userId (+ preview code if SMTP not configured), return 'twoFactor'
      if (response.twoFactorRequired) {
        setPendingTwoFactor({ userId: response.userId, previewCode: response.previewCode });
        return 'twoFactor';
      }

      const foundUser = response as User;

      if (foundUser.status !== 'active') {
        if (foundUser.status === 'paused') {
          alert("Your account has been temporarily paused. Please contact your administrator.");
          return false;
        }
        if (foundUser.status === 'cancelled' || foundUser.status === 'denied') {
          alert("Your account has been deactivated.");
          return false;
        }
        alert("Your account is pending approval.");
        return false;
      }

      setUser(foundUser);
      return true;
    } catch (error) {
      console.error('Login failed:', error);
      return false;
    }
  };

  const verifyTwoFactor = async (token: string): Promise<boolean> => {
    if (!pendingTwoFactor) return false;
    try {
      const foundUser = await apiRequest<User>('/auth/2fa/verify-login', {
        method: 'POST',
        body: JSON.stringify({ userId: pendingTwoFactor.userId, token }),
      });
      if (!foundUser) return false;
      if (foundUser.status !== 'active') {
        alert("Your account is not active.");
        return false;
      }
      setPendingTwoFactor(null);
      setUser(foundUser);
      return true;
    } catch (error) {
      console.error('2FA verification failed:', error);
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('quoteus_user');
  };

  const loginWithGoogle = async (userId: string): Promise<boolean> => {
    try {
      const foundUser = await apiRequest<User>(`/users/${userId}`);
      if (!foundUser) {
        return false;
      }
      if (foundUser.role !== 'customer') {
        return false;
      }
      if (foundUser.status !== 'active') {
        return false;
      }
      setUser(foundUser);
      return true;
    } catch (error) {
      console.error('Google login failed:', error);
      return false;
    }
  };

  const register = async (
    name: string, 
    email: string, 
    password?: string, 
    role: 'broker' | 'customer' | 'manager' | 'admin' = 'broker', 
    phone?: string,
    brokerFields?: { brokerage?: string; yearsOfService?: number; productTypes?: string[] }
  ) => {
    try {
      const newUser = await apiRequest<User>('/users', {
        method: 'POST',
        body: JSON.stringify({
          name,
          email,
          phone,
          role,
          status: role === 'customer' ? 'active' : 'pending',
          password,
          ...(brokerFields?.brokerage && { brokerage: brokerFields.brokerage }),
          ...(brokerFields?.yearsOfService && { yearsOfService: brokerFields.yearsOfService }),
          ...(brokerFields?.productTypes?.length && { productTypes: brokerFields.productTypes }),
        }),
      });
      setUsers([...users, newUser]);
    } catch (error) {
      console.error('Registration failed:', error);
      throw error;
    }
  };

  const approveBroker = async (id: string) => {
    try {
      const updated = await apiRequest<User>(`/users/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'active', actorId: user?.id }),
      });
      setUsers(users.map(u => u.id === id ? updated : u));
    } catch (error) {
      console.error('Failed to approve broker:', error);
    }
  };

  const denyBroker = async (id: string) => {
    try {
      const updated = await apiRequest<User>(`/users/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'denied', actorId: user?.id }),
      });
      setUsers(users.map(u => u.id === id ? updated : u));
    } catch (error) {
      console.error('Failed to deny broker:', error);
    }
  };

  const updateUser = async (id: string, data: Partial<User>) => {
    try {
      const updated = await apiRequest<User>(`/users/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ ...data, actorId: user?.id }),
      });
      setUsers(prev => prev.map(u => u.id === id ? updated : u));
      if (user && user.id === id) {
        setUser(updated);
      }
    } catch (error) {
      console.error('Failed to update user:', error);
    }
  };

  const resetPassword = async (id: string, newPassword: string) => {
    try {
      await apiRequest(`/users/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ password: newPassword, actorId: user?.id }),
      });
      setUsers(prev => prev.map(u => u.id === id ? { ...u, password: newPassword } : u));
    } catch (error) {
      console.error('Failed to reset password:', error);
    }
  };

  const refreshUser = async () => {
    if (!user) return;
    try {
      const updated = await apiRequest<User>(`/users/${user.id}`);
      setUser(updated);
    } catch (error) {
      console.error('Failed to refresh user:', error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, users, loading, pendingTwoFactor, login, verifyTwoFactor, loginWithGoogle, logout, register, approveBroker, denyBroker, updateUser, resetPassword, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
